#!/usr/bin/env python

##__Updated__: 20_02_2018
##__Author__: Xyrus Maurer-Alcalá; maurerax@gmail.com; xyrus.maurer-alcala@izb.unibe.ch
##__Usage__: python 5t_FinalizeName.py
##__Options__: python 5t_FinalizeName.py

##################################################################################################
## This script is intended to rename the outputs of the FilterPartials script					##
## to a given 10-character that is used in the Katz lab Phylogenomic Tree building methods		##
##																								##
## Prior to running this script, ensure the following:											##
##																								##
## 1. You have assembled your transcriptome and COPIED the 'assembly' file 						##
##    (contigs.fasta, or scaffolds.fasta) to the PostAssembly Folder							##
## 2. Removed small sequences (usually sequences < 300bp) with ContigFilterPlusStats.py			##
## 3. Removed SSU/LSU sequences from your Fasta File											##
## 4. Classified your sequences as Strongly Prokaryotic/Eukaryotic or Undetermined				##
## 5. Classified the Non-Strongly Prokaryotic sequences into OGs 								##
## 6. You either know (or have inferred) the genetic code of the organism						##
## 7. You have translated the sequences and checked for the data in the RemovePartials folder	##
## 8. Partial sequences have been removed from the transcriptomic data sets						##
##																								##
## 										COMMAND Example Below									##
##									Extra Notes at Bottom of Script								##
##																								##
## 					E-mail Xyrus (author) for help if needed: maurerax@gmail.com				##
##																								##
##										Next Script(s) to Run: 									##
##                                     NONE! You're FINISHED! :D                                ##
##																								##
##################################################################################################

import argparse, os, sys, time
from argparse import RawTextHelpFormatter,SUPPRESS

###########################################################################################
#------------------------------ Colors For Print Statements ------------------------------#
###########################################################################################

class color:
   PURPLE = '\033[95m'
   CYAN = '\033[96m'
   DARKCYAN = '\033[36m'
   ORANGE = '\033[38;5;214m'
   BLUE = '\033[94m'
   GREEN = '\033[92m'
   YELLOW = '\033[93m'
   RED = '\033[91m'
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'


###########################################################################################
#-----------------------------------------------------------------------------------------#
#------------------------------- Main Functions of Script --------------------------------#
#-----------------------------------------------------------------------------------------#
###########################################################################################

###########################################################################################
###--------------------- Parses and Checks Command-Line Arguments ----------------------###
###########################################################################################

def check_args():

	parser = argparse.ArgumentParser(description=
	color.BOLD + '\n\nThis script is intended to '+color.RED+'Rename '+color.END\
	+color.BOLD+'the core set of '+color.ORANGE+'ORFs'+color.END+color.BOLD+' with a unique'\
	+color.RED+'\nspecies identifier.'+color.END+color.BOLD+' Note that this was originially '\
	'intended for use in\nthe '+color.PURPLE+'KatzLab Phylogenomic Pipeline'+color.END+color.BOLD\
	+', which the examples follow.'+usage_msg(), usage=SUPPRESS, formatter_class=RawTextHelpFormatter)
	
	required_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Required Options'+color.END)
 
	required_arg_group.add_argument('--input_file','-in', action='store',
	help=color.BOLD+color.GREEN+' One of the Fasta files that is to be renamed\n'+color.END)
	required_arg_group.add_argument('--name','-n', action='store',
	help=color.BOLD+color.GREEN+' New unique species identifier for the transcriptome data\n'+color.END)


	optional_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Options'+color.END)

	optional_arg_group.add_argument('--custom_name','-c', action='store_true',
	help=color.BOLD+color.GREEN+' Allows for a customizable identifier\n (i.e. not the standard'\
	' "10-character" format)\n'+color.END)

	optional_arg_group.add_argument('-author', action='store_true',
	help=color.BOLD+color.GREEN+' Prints author contact information\n'+color.END)


	if len(sys.argv[1:]) == 0:
		print (parser.description)
		print ('\n')
		print (color.BOLD+color.ORANGE+'\tQuestions/Comments? Email Xyrus (author) at'\
		' maurerax@gmail.com or xyrus.maurer-alcala@izb.unibe.ch\n\n'+color.END)
		sys.exit()

	args = parser.parse_args()

	if args.author == True:
		print (color.BOLD+color.ORANGE+'\n\n\tQuestions/Comments? Email Xyrus (author) at'\
		' maurerax@gmail.com or xyrus.maurer-alcala@izb.unibe.ch\n\n'+color.END)
		if len(sys.argv[1:]) == 1:
			sys.exit()
	
	check_inputs(args)
	
	if args.custom_name == False:
		check_species_identifier(args)
	else:
		print (color.BOLD+'\n'+'#'*70+'\n\nRenaming all the '+color.ORANGE+args.input_file.split('/')[-1]\
		.split('_Filtered')[0]+color.END+color.BOLD+' files with the following '+color.PURPLE+\
		'custom'+color.END+color.BOLD+'\nspecies identifier: '+color.GREEN+args.name+color.END+'\n')
		print(color.BOLD+'#'*70+'\n'+color.END)
		
	args.home = '../'+args.aa_file.split('_Filtered.Final.')[0].split('/')[-1]+'/'

	args.file_prefix_home = args.home+'Renamed/'

	args.xml_file = args.name+'_XX_'+args.aa_file.split('/')[-1]+'_1e-10keepall_BlastOutall.oneHit'

	args.aa_r2g = '../../../ReadyToGo/ReadyToGo_AA/'	
	args.ntd_r2g = '../../../ReadyToGo/ReadyToGo_NTD/'
	args.tsv_r2g = '../../../ReadyToGo/ReadyToGo_TSV/'
	args.xml_r2g = '../../../ReadyToGo/ReadyToGo_XML/'

	return args


###########################################################################################
###------------------------------- Script Usage Message --------------------------------###
###########################################################################################

def usage_msg():

	katzlab_code = color.BOLD+color.RED+'\n\nExample usage:\n'+color.CYAN+' python 5t_FinalizeName.py'\
	' --input_file ../ToRename/Op_me_Xxma_Filtered.Final.AA.ORF.fasta --name Op_me_Xxma'+color.END
	
	custom_code = color.BOLD+color.RED+'\n\nExample usage (custom name):\n'+color.CYAN+' python '\
	'5t_FinalizeName.py --input_file ../ToRename/Blepharisma_americanum_Filtered.Final.AA.ORF.fasta '\
	'--name Sr_ci_he_Bame --custom_name'+color.END
	
	return (katzlab_code+'\n'+custom_code+'\n')


##########################################################################################
###---------------------- Ensures All Necessary Files Are Present ---------------------###
##########################################################################################

def check_inputs(args):
	quit_states = 0
	missing_files = []
	if args.input_file.endswith('.AA.ORF.fasta'):
		args.aa_file = args.input_file
		args.ntd_file = args.input_file.replace('.AA.ORF.fasta','.NTD.ORF.fasta')
		args.tsv_file = args.input_file.replace('.AA.ORF.fasta','.allOGCleanresults.tsv')
		
		if os.path.isfile(args.aa_file) != True:
			quit_states += 1
			missing_files.append(color.CYAN+args.aa_file.split('/')[-1]+color.END)
		if os.path.isfile(args.ntd_file) != True:
			quit_states += 1
			missing_files.append(color.GREEN+args.ntd_file.split('/')[-1]+color.END)
		if os.path.isfile(args.tsv_file) != True:
			quit_states += 1
			missing_files.append(color.PURPLE+args.tsv_file.split('/')[-1]+color.END)

	elif args.input_file.endswith('.NTD.ORF.fasta'):
		args.ntd_file = args.input_file
		args.aa_file = args.input_file.replace('.NTD.ORF.fasta','.AA.ORF.fasta')
		args.tsv_file = args.input_file.replace('.NTD.ORF.fasta','.allOGCleanresults.tsv')

		if os.path.isfile(args.ntd_file) != True:
			quit_states += 1
			missing_files.append(color.GREEN+args.ntd_file.split('/')[-1]+color.END)
		if os.path.isfile(args.aa_file) != True:
			quit_states += 1
			missing_files.append(color.CYAN+args.aa_file.split('/')[-1]+color.END)
		if os.path.isfile(args.tsv_file) != True:
			quit_states += 1
			missing_files.append(color.PURPLE+args.tsv_file.split('/')[-1]+color.END)

	elif args.input_file.endswith('.allOGCleanresults.tsv'):
		args.tsv_file = args.input_file
		args.ntd_file = args.input_file.replace('.allOGCleanresults.tsv','.NTD.ORF.fasta')
		args.aa_file = args.input_file.replace('.allOGCleanresults.tsv','.AA.ORF.fasta')


		if os.path.isfile(args.input_file) != True:
			quit_states += 1
			missing_files.append(color.PURPLE+args.tsv_file.split('/')[-1]+color.END)
		if os.path.isfile(args.ntd_file) != True:
			quit_states += 1
			missing_files.append(color.GREEN+args.ntd_file.split('/')[-1]+color.END)
		if os.path.isfile(args.aa_file) != True:
			quit_states += 1
			missing_files.append(color.CYAN+args.aa_file.split('/')[-1]+color.END)
	else:
		quit_states += 1
		missing_files = [color.CYAN+'"AA.ORF.fasta"'+color.END,color.GREEN+'"NTD.ORF.fasta"'+color.END,\
		color.PURPLE+'"allOGCleanresults.tsv"'+color.END]
		print (color.BOLD+'\n'+color.RED+'#'*70+'\n\nError'+color.END+color.BOLD+': No valid'\
		' files were found in the '+color.ORANGE+'ToRename'+color.END+color.BOLD+' folder.\n'\
		'\nEnsure that files all the files for the given transcriptome\nare in this folder '\
		'(see below for the expected files suffixes).\n'+color.END)
		for i in missing_files:
			print (color.BOLD+'\t'+i+'\n')
		sys.exit()
		
	if quit_states > 0:
		
		print (color.BOLD+'\n'+color.RED+'#'*70+'\n\nError'+color.END+color.BOLD+': Missing '\
		' at least one file that should be in the '+color.ORANGE+'ToRename'+color.END+\
		color.BOLD+' folder.\n\nCheck that the missing files (see below) are in the '+color.ORANGE+\
		'ToRename'+color.END+color.BOLD+' folder.\n'+color.END)
		for i in missing_files:
			print (color.BOLD+'\t'+i+'\n')
		sys.exit()


###########################################################################################
###-------------------- Checks Format for Given Species Identifier ---------------------###
###########################################################################################

def check_species_identifier(args):
	
	examples = ['Sr_ci_Cunc','Op_me_Hsap','Am_di_Ddis']
	
	name_split = args.name.split('_')
	
	if len(args.name) != 10:
		print (color.BOLD+'\n'+color.RED+'#'*70+'\n\nError'+color.END+color.BOLD+': Provided '
		'species identifier is not 10 characters long.\n\nBelow are three examples:\n'+color.END)
		for i in examples:
			print (color.BOLD+color.DARKCYAN+i+'\n'+color.END)
		sys.exit()
	
	elif args.name.count('_') != 2:
		print (color.BOLD+'\n'+color.RED+'#'*70+'\n\nError'+color.END+color.BOLD+': Provided '
		'species identifier is improperly formatted.\n\nBelow are three examples:\n'+color.END)
		for i in examples:
			print (color.BOLD+color.DARKCYAN+i+'\n'+color.END)
		sys.exit()

	if len(name_split[0]) == 2 and len(name_split[1]) == 2 and len(name_split[2]) == 4:
		print (color.BOLD+'\n'+'#'*70+'\n\nRenaming all the '+color.ORANGE+args.input_file.split('/')[-1]\
		.split('_Filtered')[0]+color.END+color.BOLD+' files with the following species'\
		'\nidentifier: '+color.GREEN+args.name+color.END+'\n')
		print(color.BOLD+'#'*70+'\n'+color.END)
	else:
		print (color.BOLD+'\n'+color.RED+'#'*70+'\n\nError'+color.END+color.BOLD+': Provided '
		'species identifier is improperly formatted.\n\nBelow are three examples:\n'+color.END)
		for i in examples:
			print (color.BOLD+color.DARKCYAN+i+'\n'+color.END)
		sys.exit()
		
			
##########################################################################################
###------------------------- Creates Folders For Storing Data -------------------------###
##########################################################################################

def prep_folders(args):
	
	if os.path.isdir('../../../ReadyToGo/') != True:
		os.system('mkdir ../../../ReadyToGo')

	if os.path.isdir(args.aa_r2g) != True:
		os.system('mkdir '+args.aa_r2g)
	if os.path.isdir(args.ntd_r2g) != True:
		os.system('mkdir '+args.ntd_r2g)
	if os.path.isdir(args.tsv_r2g) != True:
		os.system('mkdir '+args.tsv_r2g)
	if os.path.isdir(args.xml_r2g) != True:
		os.system('mkdir '+args.xml_r2g)

	if os.path.isdir(args.file_prefix_home) != True:
		os.system('mkdir '+args.file_prefix_home)

	if os.path.isdir('../Finished/') != True:
		os.system('mkdir ../Finished')


#-----------------------------------------------------------------------------------------#
#------------- File Update Step (Appending New Species Identifier -- Quick) --------------#
#-----------------------------------------------------------------------------------------#

###########################################################################################
###---------------- Renames the Files with the Given Species Identifier ----------------###
###########################################################################################

def rename_data(args):

	renamed_Final_Prots = open(args.aa_file).read().replace('>','>'+args.name+'_XX_')
	
	renamed_Final_Nucs = open(args.ntd_file).read().replace('>','>'+args.name+'_XX_')

	renamed_Final_tsv = [args.name+'_XX_'+i for i in open(args.tsv_file).read().split('\n') if i != '']
		
	with open(args.file_prefix_home+args.name+'_XX_'+args.aa_file.split('/')[-1],'w+') as w:
		w.write(renamed_Final_Prots)

	with open(args.file_prefix_home+args.name+'_XX_'+args.ntd_file.split('/')[-1],'w+') as x:
		x.write(renamed_Final_Nucs)

	with open(args.file_prefix_home+args.name+'_XX_'+args.tsv_file.split('/')[-1],'w+') as y:
		y.write('\n'.join(renamed_Final_tsv))

	return renamed_Final_tsv


#-----------------------------------------------------------------------------------------#
#----------------------------- "Fake" XML Generation Steps -------------------------------#
#-----------------------------------------------------------------------------------------#

###########################################################################################
###------------------------------- TSV to XML Conversion -------------------------------###
###########################################################################################

def convert_TSV_data(args, final_tsv):

	if args.custom_name == True:

		print (color.BOLD+'Preparing an XML file for '+color.ORANGE+args.input_file.split('/')[-1]\
		.split('_Filtered')[0]+color.END+color.BOLD+' files with the following '+color.PURPLE+\
		'custom'+color.END+color.BOLD+'\nspecies identifier: '+color.GREEN+args.name+color.END+'\n')
	
	else:
	
		print (color.BOLD+'Preparing an XML file for '+color.ORANGE+args.input_file.split('/')[-1]\
		.split('_Filtered')[0]+color.END+color.BOLD+' using the following\nspecies identifier:'\
		' '+color.GREEN+args.name+color.END+'\n')
		
	
	header = '<?xml version="1.0"?>\n<!DOCTYPE BlastOutput PUBLIC "-//NCBI//NCBI BlastOutput/EN" "http://www.ncbi.nlm.nih.gov/dtd/NCBI_BlastOutput.dtd">\n'\
	'<BlastOutput>\n  <BlastOutput_program>blastp</BlastOutput_program>\n  <BlastOutput_version>BLASTP 2.2.29+</BlastOutput_version>\n'\
	'  <BlastOutput_reference>Stephen F. Altschul, Thomas L. Madden, Alejandro A. Sch&amp;auml;ffer, Jinghui Zhang, Zheng Zhang, Webb Miller, and David J. Lipman (1997), &quot;Gapped BLAST and PSI-BLAST: a new generation of protein database search programs&quot;, Nucleic Acids Res. 25:3389-3402.</BlastOutput_reference>\n'\
	'  <BlastOutput_db>../OGBlastDB/renamed_aa_seqs_OrthoMCL-5_12653.fasta</BlastOutput_db>\n  <BlastOutput_query-ID>Query_1</BlastOutput_query-ID>\n'

	tail = '</BlastOutput_iterations>\n</BlastOutput>'

	iterations = []
	
	for n in range(len(final_tsv)):
		if n == 0:
			iterations.append('  <BlastOutput_query-def>'+final_tsv[n].split('\t')[0]+'</BlastOutput_query-def>\n  <BlastOutput_query-len>'+str(abs(int(final_tsv[n].split('\t')[-3])-int(final_tsv[n].split('\t')[-4])+1))+'</BlastOutput_query-len>\n'\
				'  <BlastOutput_param>\n    <Parameters>\n      <Parameters_matrix>BLOSUM62</Parameters_matrix>\n      <Parameters_expect>1e-10</Parameters_expect>\n'\
				'      <Parameters_gap-open>11</Parameters_gap-open>\n      <Parameters_gap-extend>1</Parameters_gap-extend>\n      <Parameters_filter>F</Parameters_filter>\n'\
				'    </Parameters>\n  </BlastOutput_param>\n<BlastOutput_iterations>\n<Iteration>\n  <Iteration_iter-num>1</Iteration_iter-num>\n  <Iteration_query-ID>Query_1</Iteration_query-ID>\n'\
				'  <Iteration_query-def>'+final_tsv[n].split('\t')[0]+'</Iteration_query-def>\n  <Iteration_query-len>'+str(abs(int(final_tsv[n].split('\t')[-3])-int(final_tsv[n].split('\t')[-4])+1))+'</Iteration_query-len>\n'\
				'<Iteration_hits>\n<Hit>\n  <Hit_num>1</Hit_num>\n  <Hit_id>Fake_Entry</Hit_id>\n  <Hit_def>'+final_tsv[n].split('\t')[1]+'</Hit_def>\n  <Hit_accession>Fake_Accession</Hit_accession>\n'\
				'  <Hit_len>'+str(abs(int(final_tsv[n].split('\t')[-3])-int(final_tsv[n].split('\t')[-4])+1))+'</Hit_len>\n  <Hit_hsps>\n    <Hsp>\n      <Hsp_num>1</Hsp_num>\n      <Hsp_bit-score>1234</Hsp_bit-score>\n'\
				'      <Hsp_score>'+final_tsv[n].split('\t')[-1]+'</Hsp_score>\n      <Hsp_evalue>'+final_tsv[n].split('\t')[-2]+'</Hsp_evalue>\n      <Hsp_query-from>'+final_tsv[n].split('\t')[-4]+'</Hsp_query-from>\n'\
				'      <Hsp_query-to>'+final_tsv[n].split('\t')[-3]+'</Hsp_query-to>\n      <Hsp_hit-from>'+final_tsv[n].split('\t')[-4]+'</Hsp_hit-from>\n      <Hsp_hit-to>'+final_tsv[n].split('\t')[-3]+'</Hsp_hit-to>\n'\
				'      <Hsp_query-frame>0</Hsp_query-frame>\n      <Hsp_hit-frame>0</Hsp_hit-frame>\n      <Hsp_identity>'+str(abs(int(final_tsv[n].split('\t')[-3])-int(final_tsv[n].split('\t')[-4])))+'</Hsp_identity>\n'\
				'      <Hsp_positive>'+str(abs(int(final_tsv[n].split('\t')[-3])-int(final_tsv[n].split('\t')[-4])))+'</Hsp_positive>\n      <Hsp_gaps>0</Hsp_gaps>\n      <Hsp_align-len>'+str(abs(int(final_tsv[n].split('\t')[-3])-int(final_tsv[n].split('\t')[-4])))+'</Hsp_align-len>\n'\
				'      <Hsp_qseq></Hsp_qseq>\n      <Hsp_hseq></Hsp_hseq>\n      <Hsp_midline></Hsp_midline>\n    </Hsp>\n  </Hit_hsps>\n</Hit>\n'\
				'\n</Iteration_hits>\n  <Iteration_stat>\n    <Statistics>\n      <Statistics_db-num>379660</Statistics_db-num>\n      <Statistics_db-len>197499634</Statistics_db-len>\n'\
				'      <Statistics_hsp-len>123</Statistics_hsp-len>\n      <Statistics_eff-space>184705217500</Statistics_eff-space>\n      <Statistics_kappa>0.041</Statistics_kappa>\n'\
				'      <Statistics_lambda>0.267</Statistics_lambda>\n      <Statistics_entropy>0.14</Statistics_entropy>\n    </Statistics>\n  </Iteration_stat>\n</Iteration>\n')
		else:
			iterations.append('<Iteration>\n  <Iteration_iter-num>'+str(n+1)+'</Iteration_iter-num>\n  <Iteration_query-ID>Query_'+str(n+1)+'</Iteration_query-ID>\n'\
				'  <Iteration_query-def>'+final_tsv[n].split('\t')[0]+'</Iteration_query-def>\n  <Iteration_query-len>'+str(abs(int(final_tsv[n].split('\t')[-3])-int(final_tsv[n].split('\t')[-4])+1))+'</Iteration_query-len>\n'\
				'<Iteration_hits>\n<Hit>\n  <Hit_num>1</Hit_num>\n  <Hit_id>Fake_Entry</Hit_id>\n  <Hit_def>'+final_tsv[n].split('\t')[1]+'</Hit_def>\n  <Hit_accession>Fake_Accession</Hit_accession>\n'\
				'  <Hit_len>'+str(abs(int(final_tsv[n].split('\t')[-3])-int(final_tsv[n].split('\t')[-4])+1))+'</Hit_len>\n  <Hit_hsps>\n    <Hsp>\n      <Hsp_num>1</Hsp_num>\n      <Hsp_bit-score>1234</Hsp_bit-score>\n'\
				'      <Hsp_score>'+final_tsv[n].split('\t')[-1]+'</Hsp_score>\n      <Hsp_evalue>'+final_tsv[n].split('\t')[-2]+'</Hsp_evalue>\n      <Hsp_query-from>'+final_tsv[n].split('\t')[-4]+'</Hsp_query-from>\n'\
				'      <Hsp_query-to>'+final_tsv[n].split('\t')[-3]+'</Hsp_query-to>\n      <Hsp_hit-from>'+final_tsv[n].split('\t')[-4]+'</Hsp_hit-from>\n      <Hsp_hit-to>'+final_tsv[n].split('\t')[-3]+'</Hsp_hit-to>\n'\
				'      <Hsp_query-frame>0</Hsp_query-frame>\n      <Hsp_hit-frame>0</Hsp_hit-frame>\n      <Hsp_identity>'+str(abs(int(final_tsv[n].split('\t')[-3])-int(final_tsv[n].split('\t')[-4])))+'</Hsp_identity>\n'\
				'      <Hsp_positive>'+str(abs(int(final_tsv[n].split('\t')[-3])-int(final_tsv[n].split('\t')[-4])))+'</Hsp_positive>\n      <Hsp_gaps>0</Hsp_gaps>\n      <Hsp_align-len>'+str(abs(int(final_tsv[n].split('\t')[-3])-int(final_tsv[n].split('\t')[-4])))+'</Hsp_align-len>\n'\
				'      <Hsp_qseq></Hsp_qseq>\n      <Hsp_hseq></Hsp_hseq>\n      <Hsp_midline></Hsp_midline>\n    </Hsp>\n  </Hit_hsps>\n</Hit>\n'\
				'\n</Iteration_hits>\n  <Iteration_stat>\n    <Statistics>\n      <Statistics_db-num>379660</Statistics_db-num>\n      <Statistics_db-len>197499634</Statistics_db-len>\n'\
				'      <Statistics_hsp-len>123</Statistics_hsp-len>\n      <Statistics_eff-space>184705217500</Statistics_eff-space>\n      <Statistics_kappa>0.041</Statistics_kappa>\n'\
				'      <Statistics_lambda>0.267</Statistics_lambda>\n      <Statistics_entropy>0.14</Statistics_entropy>\n    </Statistics>\n  </Iteration_stat>\n</Iteration>\n')

	with open(args.file_prefix_home+args.xml_file,'w+') as w:
		w.write(header)
		w.write(''.join(iterations))
		w.write(tail)

	
##########################################################################################
###-------------------- Cleans up the Folder and Moves Final Files --------------------###
##########################################################################################

def clean_up(args):

	os.system('cp '+args.file_prefix_home+args.xml_file+' '+args.xml_r2g)
	os.system('cp '+args.file_prefix_home+args.name+'_XX_'+args.tsv_file.split('/')[-1]+' '+args.tsv_r2g)
	os.system('cp '+args.file_prefix_home+args.name+'_XX_'+args.ntd_file.split('/')[-1]+' '+args.ntd_r2g)
	os.system('cp '+args.file_prefix_home+args.name+'_XX_'+args.aa_file.split('/')[-1]+' '+args.aa_r2g)


	os.system('rm '+args.aa_file)
	os.system('rm '+args.ntd_file)
	os.system('rm '+args.tsv_file)
	
	
	os.system('mv '+args.home+' ../Finished/')
	

###########################################################################################
###-------------------------------- Next Script Message --------------------------------###
###########################################################################################

def next_script(args):
	
	print(color.BOLD+'#'*70+'\n'+color.END)
	
	print(color.BOLD+'There is no next script!\n\nThe final '+color.ORANGE+args.input_file\
	.split('/')[-1].split('_Filtered')[0]+color.END+color.BOLD+' files can be found in their'\
	' respective\n'+color.RED+'ReadyToGo'+color.END+color.BOLD+' folders (see the main '\
	'"HTS_Processing" folder).\n\nThese data are also ready for any downstream '+color.RED+\
	'phylogenomic analyses'+color.END+color.BOLD+'!\n'+color.END)

	print(color.BOLD+'#'*70+'\n'+color.END)

	print(color.BOLD+'\n'+' '*6+color.GREEN+'Thank you'+color.END+\
	color.BOLD+' for using these scripts!\n\n'+' '*6+'--'+color.ORANGE+'Xyrus'+color.END+\
	color.BOLD+'--\n\n'+color.END)
	
##########################################################################################
###--------------- Checks Command Line Arguments and Calls on Functions ---------------###
##########################################################################################
			
def main():

	start = time.time()

	args = check_args()
		
	prep_folders(args)
	
	final_tsv = rename_data(args)
	
	convert_TSV_data(args, final_tsv)
	
	clean_up(args)
	
	next_script(args)
	
	end = time.time()
	
	hours, rem = divmod(end-start, 3600)
	minutes, seconds = divmod(rem, 60)
	print(color.BOLD+'Total Running Time:   \t'+"{:0>2}:{:0>2}:{:05.2f}".format(int(hours),int(minutes),seconds)+'\n'+color.END)

	
main()