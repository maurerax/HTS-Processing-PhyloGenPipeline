#!/usr/bin/env python3

##__Updated__: 02_02_2018
##__Author__: Xyrus Maurer-Alcalá; maurerax@gmail.com; xyrus.maurer-alcala@izb.unibe.ch
##__Usage__: python 1_FilterTranscripts.py
##__Options__: python 1_FilterTranscripts.py --help

##########################################################################################
## This script is intended to remove small transcripts or small contigs below a given   ##
## minimum size from a transcriptome assembly.                                          ##
##                                                                                      ##
## Prior to running this script, ensure the following:                                  ##
## 1. You have assembled your transcriptome and COPIED the 'assembly' file              ##
##    (contigs.fasta, or scaffolds.fasta) to the PostAssembly Folder                    ##
##                                                                                      ##
##                                                                                      ##
##                       E-mail Xyrus (author) for help if needed                       ##
##                                                                                      ##
##########################################################################################

import argparse, os, shutil, sys, time
from argparse import RawTextHelpFormatter,SUPPRESS
from Bio import SeqIO
from Bio.SeqUtils import GC


#------------------------------ Colors For Print Statements ------------------------------#

class color:
   PURPLE = '\033[95m'
   CYAN = '\033[96m'
   DARKCYAN = '\033[36m'
   ORANGE = '\033[38;5;214m'
   BLUE = '\033[94m'
   GREEN = '\033[92m'
   YELLOW = '\033[93m'
   RED = '\033[91m'
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'


#-----------------------------------------------------------------------------------------#
#-------------------------- Validates Arguments and Dependencies -------------------------#
#-----------------------------------------------------------------------------------------#
###########################################################################################
###-------------------- Checks that the executables are in the PATH --------------------###
###########################################################################################

def validate_executables():
	
	missing_from_path = []
	
	if shutil.which('blastn') == None:
		missing_from_path.append('BLAST')
	if shutil.which('usearch') == None:
		missing_from_path.append('USearch')
	
	if len(missing_from_path) > 0:
		print (color.BOLD+color.RED+'\nError:'+color.END+color.BOLD+' The following programs '\
		'are missing from your "PATH":\n\n'+color.END)
		for i in missing_from_path:
			print (color.GREEN+'   '+i+color.END+'\n')
		print (color.BOLD+'\nEnsure that they are installed in the PATH prior to running '\
		'this script\n\n'+color.END)
		sys.exit()
	else:
		pass
		


def check_args():

	parser = argparse.ArgumentParser(description=
	color.BOLD+'\nThis script will remove '+color.RED+'rDNA contigs (both SSU and LSU)'+color.END\
	+color.BOLD+'\nfrom your Assembly using a set of '+color.RED+'SSU/LSU rDNAs '+color.END\
	+color.BOLD+'from diverse\n'+color.ORANGE+'Eukaryotes, Bacteria and Archaea'+color.END\
	+color.BOLD+'.'+color.END+usage_msg(), usage=SUPPRESS,formatter_class=RawTextHelpFormatter)
	
	required_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Required Options'+color.END)
 
	required_arg_group.add_argument('--input_file','-in', action='store',
	help=color.BOLD+color.GREEN+"Fasta file of Nucleotide sequences"+color.END)

	optional_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Options'+color.END)
	optional_arg_group.add_argument('--size','-s', action='store_true',
	help=color.BOLD+color.GREEN+' Remove sequences smaller than a given threshold\n'+color.END)
	optional_arg_group.add_argument('--rRNA','-r', action='store_true',
	help=color.BOLD+color.GREEN+' Performs bulk rRNA removal\n'+color.END)
	optional_arg_group.add_argument('--BvE','-b', action='store_true',
	help=color.BOLD+color.GREEN+' Removes strongly "prokaryotic" transcripts\n'+color.END)
	optional_arg_group.add_argument('-author', action='store_true',
	help=color.BOLD+color.GREEN+' Print author contact information\n'+color.END)

	optional_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Size-Related Options'+color.END)
	optional_arg_group.add_argument('--minlen','-len', action='store', default='200',
	help=color.BOLD+color.GREEN+' Minimum length (in bp) of transcripts to keep\n'+color.END)
	optional_arg_group.add_argument('--output_file','-out',
	help=color.BOLD+color.GREEN+" Desired Output Name\n (must include 'rna' and minimum length)\n"+color.END)
	optional_arg_group.add_argument('--spades','-spades', action='store_true',
	help=color.BOLD+color.GREEN+' rnaSPAdes transcriptome assembly\n'+color.END)
	optional_arg_group.add_argument('--genbank','-gb', action='store_true',
	help=color.BOLD+color.GREEN+' Assembly from Genbank\n (Will include Accession Number in'\
	' contig name)\n'+color.END)
	
	optional_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'rRNA Options'+color.END)
	optional_arg_group.add_argument('--threads','-t', action='store', default='2',
	help=color.BOLD+color.GREEN+' Threads to use for BLASTn and UBlast\n'+color.END)

	optional_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Prokaryote versus Eukaryote Options'+color.END)
	optional_arg_group.add_argument('--stringency','-stringency', default = 'high',
	help=color.BOLD+color.GREEN+' Relative stringency threshold for\n identifying Strongly '\
	'Prokaryotic sequences\n ("high" or "low"; default: "high")\n'+\
	' Or can input ratio ("Bact":"Euk"; e.g. 10000)\n'+color.END)

	if len(sys.argv[1:]) == 0:
		print (parser.description)
		print ('\n')
		sys.exit()

	args = parser.parse_args()
	
	if args.author == True:
		print (color.BOLD+color.ORANGE+'\n\n\tQuestions/Comments? Email Xyrus (author) at'\
		' maurerax@gmail.com or xyrus.maurer-alcala@izb.unibe.ch\n\n'+color.END)
	
	
	validate_executables()


	eval_args(args)
	
	return args

###########################################################################################
###------------------------------- Script Usage Message --------------------------------###
###########################################################################################

def usage_msg():
	return color.BOLD+color.RED+'\n\nExample usage (All Steps):\n\n'+color.CYAN+'   python '\
	'1_FilterTranscripts.py --input_file ../Op_me_Xxma_transcripts_rnaSpades.fasta --output_file'\
	' Op_me_Xxma_transcripts_RNA --size --rRNA --BvE --stringency high --spades'+\
	color.BOLD+color.RED+'\n\nExample usage (Sequentially):\n\n'+color.CYAN+'   python '\
	'1_FilterTranscripts.py --input_file ../Op_me_Xxma_transcripts_rnaSpades.fasta --output_file'\
	' Op_me_Xxma_transcripts_RNA --size --spades \n\n   python 1_FilterTranscripts.py '\
	'--input_file ../Op_me_Xxma_transcripts_RNA/SizeFiltered/Op_me_Xxma_transcripts_RNA.200bp.fasta'\
	' --rRNA\n\n   python 1_FilterTranscripts.py --input_file ../Op_me_Xxma_transcripts_RNA/'\
	'rRNA_Removal/Op_me_Xxma_transcripts_RNA_NorRNAseqs.fasta --BvE --stringency high'+color.END




def eval_args(args):

	if args.size == args.rRNA == args.BvE:
		args.size = args.rRNA = args.BvE = True

		check_input_size(args)

		args.home_folder = '../'+args.output_file
		args.rRNA_input = '../'+args.output_file+'/SizeFiltered/'+args.output_file+'.'+\
		args.minlen+'bp.fasta'
		
		args.BvE_input = '.'.join(args.rRNA_input.replace('/SizeFiltered/','/rRNA_Removal/')\
		.split('bp.fasta')[0].split('.')[:-1])+'_NorRNAseqs.fasta'
		
	elif args.size == True and args.rRNA == args.BvE == False:		
		check_input_size(args)

	elif args.rRNA == True and args.size == args.BvE == False:		
		args.rRNA_input = args.input_file
		check_input_rRNA(args)

	elif args.BvE == True and args.size == args.rRNA == False:		
		args.BvE_input = args.input_file
		check_input_BvE(args)


###########################################################################################
###--------------------------- Checks the input file format ----------------------------###
###########################################################################################

def check_input_size(args):
	if args.input_file != None and os.path.isfile(args.input_file) != False:
		if args.input_file.split('/')[-1] not in os.listdir('../'):
			print (color.BOLD+color.RED+'\nError:'+color.END+color.BOLD+' The provided Fasta file '\
			'('+color.DARKCYAN+args.input_file.split('/')[-1]+color.END+color.BOLD+')\nmust be '\
			'in the main '+color.RED+'Transcriptomes'+color.END+color.BOLD+' folder.\n\n'\
			'Double-check then try again!\n'+color.END) 
			sys.exit()
	else:
		print (color.BOLD+color.RED+'\nError:'+color.END+color.BOLD+' The provided Fasta file '\
		'('+color.DARKCYAN+args.input_file.split('/')[-1]+color.END+color.BOLD+')\ndoes not'\
		' exist or is not in that directory/location.\n\nDouble-check then try again!\n'+color.END)
		sys.exit()

	if args.output_file == None:
		print ('\n'+color.BOLD+color.RED+'#'*70+'\n'+color.END)
		print (color.BOLD+color.RED+'Warning'+color.END+color.BOLD+': No output name was provided...')
		print ('Note: The name must include "'+color.ORANGE+'RNA'+color.END+color.BOLD+'"\n')
		if int(sys.version[0]) > 2:
			x = input('Would you like to include one now?  (y or n):  ')
		else:
			x = raw_input('Would you like to include one now?  (y or n):  ')
		if x.lower() != 'y' and x.lower() != 'yes':
			print ('\n'+color.RED+'Exiting'+color.END+color.BOLD+', but please include a vaild'\
			' output-name next time.\n'+color.END)
			sys.exit()
		else:
			if int(sys.version[0]) > 2:
				name = input('Enter name: ')
			else:
				name = raw_input('Enter name: ')
			print(color.END)
			if 'rna' not in name.lower():
				print (color.BOLD+color.RED+'\n"RNA" '+color.END+color.BOLD+'is not in the name...'\
				'\n'+color.RED+'Exiting'+color.END+color.BOLD+', but please include a vaild'\
				' output-name next time.\n'+color.END)
				sys.exit()
			else:
				args.output_file = name


def check_input_rRNA(args):

	if args.rRNA_input.endswith('bp.fasta') != True:
		print ('\n'+color.BOLD+color.RED+'#'*70+'\n'+color.END)
		print (color.BOLD+color.RED+'Error:'+color.END+color.BOLD+': The expected '\
		'"\ninput Fasta File MUST include "'+color.RED+'rna'+color.END+color.BOLD+\
		'in its name and MUST end with "'+color.RED+'bp.fasta'+color.END+color.BOLD\
		+'".\n'+color.END)
		sys.exit()

	if 'rna' not in args.rRNA_input.lower():
		print ('\n'+color.BOLD+color.RED+'#'*70+'\n'+color.END)
		print (color.BOLD+color.RED+'Error:'+color.END+color.BOLD+': The expected '\
		'input Fasta File MUST include "'+color.RED+'rna'+color.END+color.BOLD+\
		'"\nin its name and MUST end with "'+color.RED+'bp.fasta'+color.END+color.BOLD\
		+'".\n'+color.END)
		sys.exit()


def check_input_BvE(args):

	if args.BvE_input.endswith('NorRNAseqs.fasta') != True:
		print ('\n'+color.BOLD+color.RED+'#'*70+'\n'+color.END)
		print (color.BOLD+color.RED+'Error:'+color.END+color.BOLD+': The expected '\
		'input Fasta File end with "'+color.RED+'NorRNAseqs.fasta'+color.END+color.BOLD\
		+'".\n'+color.END)
		sys.exit()


def check_rRNA_db():
		
	if os.path.isdir('../../Databases/db_BvsE') != True:
		print ('\n'+color.BOLD+color.RED+'#'*70+'\n'+color.END)
		print (color.BOLD+color.RED+'Error'+color.END+color.BOLD+': Cannot find the '\
		+color.ORANGE+'db_BvsE Folder!\n\n'+color.END+color.BOLD+'Ensure that this folder '\
		'can be found in the main '+color.ORANGE+'Databases Folder'+color.END+color.BOLD\
		+'\n\nThen try once again.'+color.END)
		sys.exit()
		
	elif os.path.isfile('../../Databases/db_BvsE/SSULSUdb.nhr') != True:
		print ('\n'+color.BOLD+color.RED+'#'*70+'\n'+color.END)
		print (color.BOLD+color.RED+'Error'+color.END+color.BOLD+': Cannot find the '\
		'BLAST+ formatted '+color.ORANGE+'SSU-LSU databases!\n\n'+color.END+color.BOLD+\
		'Ensure that they can be found in the '+color.ORANGE+'db_BvsE folder'+color.END+\
		color.BOLD+',\nwhich can be found in the main '+color.ORANGE+'Databases Folder'+\
		color.END+color.BOLD+'\n\nThen try once again.'+color.END)
		sys.exit()


def check_BvE_db():
		
	quit = 0

	if os.path.isdir('../../Databases/db_BvsE') != True:
		print ('\n'+color.BOLD+color.RED+'#'*70+'\n'+color.END)
		print (color.BOLD+color.RED+'Error'+color.END+color.BOLD+': Cannot find the '\
		+color.ORANGE+'db_BvsE Folder'+color.END+color.BOLD+'!\n\n'+color.END+color.BOLD+\
		'Ensure that this folder can be found in the main '+color.ORANGE+'Databases Folder'+\
		color.END+color.BOLD+'.\nThen try once again.\n'+color.END)
		sys.exit()

	mic_out = len([i for i in os.listdir('../../Databases/db_BvsE/') if 'micout' in i])
	euk_out = len([i for i in os.listdir('../../Databases/db_BvsE/') if 'eukout' in i])
	
	mic_exp = 15
	euk_exp = 9
	
	if mic_out != mic_exp:
		print ('\n'+color.BOLD+color.RED+'#'*70+'\n'+color.END)
		print (color.BOLD+color.RED+'Error'+color.END+color.BOLD+': Found '+color.ORANGE+\
		str(mic_out)+color.END+color.BOLD+'/'+color.ORANGE+str(mic_exp)+color.END+color.BOLD+\
		' of the expected Bacterial/Archaeal '+color.ORANGE+'Protein databases'+color.END)
		quit += 1

	if euk_out != euk_exp:
		if quit != 1:
			print ('\n'+color.BOLD+color.RED+'#'*70+'\n'+color.END)
		print (color.BOLD+color.RED+'Error'+color.END+color.BOLD+': Found '+color.ORANGE+\
		str(euk_out)+color.END+color.BOLD+'/'+color.ORANGE+str(euk_exp)+color.END+color.BOLD+\
		' of the expected Eukaryotic '+color.ORANGE+'Protein databases'+color.END)
		quit += 1
		
	if quit != 0:
		print (color.BOLD+'\nRe-download these using the links provided by the following '+\
		color.CYAN+'GitHub page:\n\n\tgithub.com/maurerax/HTS-Processing-PhyloGenPipeline'\
		+color.END+'\n')
		sys.exit()
		

def prep_folders(args):

	if args.size == True:
		if os.path.isdir('../'+args.output_file) != True:
			os.system('mkdir ../'+args.output_file)
		if os.path.isdir('../'+args.output_file+'/Original') != True:
			os.system('mkdir ../'+args.output_file+'/Original')
		if os.path.isdir('../'+args.output_file+'/SizeFiltered') != True:
			os.system('mkdir ../'+args.output_file+'/SizeFiltered')
		
	if args.rRNA == True:
		args.rRNAout_folder = '../'+'.'.join(args.rRNA_input.split('/')[-1].split('.')[:-2])
		if os.path.isdir(args.rRNAout_folder) != True:
			os.system('mkdir '+args.rRNAout_folder)
		if os.path.isdir(args.rRNAout_folder+'/rRNA_Removal/') != True:
			os.system('mkdir '+args.rRNAout_folder+'/rRNA_Removal/')
		if os.path.isdir(args.rRNAout_folder+'/rRNA_Removal/SpreadSheets') != True:
			os.system('mkdir '+args.rRNAout_folder+'/rRNA_Removal/SpreadSheets')	

	if args.BvE == True:
		args.BvEout_folder = '../'+args.BvE_input.split('/')[1]+'/BvE/'
		if os.path.isdir(args.BvEout_folder) != True:
			os.system('mkdir '+args.BvEout_folder)
		if os.path.isdir(args.BvEout_folder+'/SpreadSheets') != True:
			os.system('mkdir '+args.BvEout_folder+'/SpreadSheets')

		
		
#-----------------------------------------------------------------------------------------#
#------------------------------- Size-Based Filtering Steps ------------------------------#
#-----------------------------------------------------------------------------------------#

###########################################################################################
###------------------------- Keeps Sequences ≥ Minimum Length --------------------------###
###########################################################################################

def size_RemoveShort(input_file, minlen, genbank, spades):

	print (color.BOLD+'\n'+'#'*70+'\n\nPreparing to keep sequences from ≥ '+color.PURPLE+str(minlen)+\
	' base pairs'+color.END+color.BOLD+'\nfrom: '+color.DARKCYAN+input_file.split('/')[-1]+color.END)
	print (color.BOLD+'\n'+'#'*70+'\n'+color.END)

	inFasta = [i for i in SeqIO.parse(input_file,'fasta') if len(i.seq) >= minlen]
	inFasta.sort(key=lambda seq_rec: -len(seq_rec.seq))

	renamed_seqs = []
	seq_code_dict = {}

	count = 1

	if 'LKH' in input_file:
		seq_name_start = 'LKH'+input_file.split('LKH')[-1].split('_')[0]
	else:
		seq_name_start = 'Contig'

	if genbank == True:
		for seq_rec in inFasta:
			seq_code_dict.setdefault(seq_rec.id,[]).append(seq_rec.id.split('_')[-1].split('.')[0]+'_Contig_'+str(count)+'_Len'+str(len(seq_rec.seq)))
			seq_code_dict.setdefault(seq_rec.id,[]).append(str(seq_rec.seq).upper())
			renamed_seqs.append('>'+seq_rec.id.split('_')[-1].split('.')[0]+'_Contig_'+str(count)+'_Len'+str(len(seq_rec.seq))+'\n'+str(seq_rec.seq).upper())
			count += 1
	elif spades == True:
		for seq_rec in inFasta:
			seq_code_dict.setdefault(seq_rec.description,[]).append(seq_name_start+'_'+str(count)+'_Len'+str(len(seq_rec.seq))+'_Cov'+str(int(round(float(seq_rec.description.split('_')[-3])))))
			seq_code_dict.setdefault(seq_rec.description,[]).append(seq_rec.description.split('_')[5])
			seq_code_dict.setdefault(seq_rec.description,[]).append(str(seq_rec.seq).upper())
			renamed_seqs.append('>'+seq_name_start+'_'+str(count)+'_Len'+str(len(seq_rec.seq))+'_Cov'+str(int(round(float(seq_rec.description.split('_')[-3]))))+'\n'+str(seq_rec.seq).upper())
			count += 1
	else:
		for seq_rec in inFasta:
			seq_code_dict.setdefault(seq_rec.description,[]).append(seq_name_start+'_'+str(count)+'_Len'+str(len(seq_rec.seq)))
			seq_code_dict.setdefault(seq_rec.description,[]).append(str(seq_rec.seq).upper())
			renamed_seqs.append('>'+seq_name_start+'_'+str(count)+'_Len'+str(len(seq_rec.seq))+'\n'+str(seq_rec.seq).upper())
			count += 1

	return renamed_seqs, seq_code_dict

###########################################################################################
###------------------------- Writes out all the filtered data --------------------------###
###########################################################################################

def size_WriteDataOut(renamed_seqs, seq_code_dict, output_file, minlen, genbank, spades):

	print (color.BOLD+'There are '+color.RED+"{:,}".format(len(renamed_seqs))+' contigs ≥ '\
	+str(minlen)+'bp'+color.END+color.BOLD+' in '+color.DARKCYAN+output_file+'.'+str(minlen)+\
	'bp.fasta'+color.END)
	
	with open('../'+output_file+'/SizeFiltered/'+output_file+'.'+str(minlen)+'bp.fasta', 'w+') as w:
		w.write('\n'.join(renamed_seqs))
		
	if spades != True:
		with open('../'+output_file+'/SizeFiltered/'+output_file+'.SeqCodes.tsv','w+') as x:
			x.write('Original Name\tNew Name\tSeq Length\t Seq GC\n')
			for k, v in seq_code_dict.items():
				x.write(k+'\t'+v[0]+'\t'+str(len(v[1]))+'\t'+str(GC(v[1]))+'\n')

	else:
		with open('../'+output_file+'/SizeFiltered/'+output_file+'.SeqCodes.tsv','w+') as y:
			y.write('Original Name\tNew Name\tSeq Length\tSeq GC\tSeq Coverage\n')
			for k, v in seq_code_dict.items():
				y.write(k+'\t'+v[0]+'\t'+str(len(v[2]))+'\t'+str(GC(v[2]))+'\t'+str(v[1])+'\n')

###########################################################################################
###-------------------------------- Next Script Message --------------------------------###
###########################################################################################

def size_next_script(output_file, minlen):

	print (color.BOLD+'\n'+'#'*70+'\n'+color.END)

	print (color.BOLD+'Look for '+color.DARKCYAN+output_file+'.'+str(minlen)+'bp.fasta'\
	+color.END+color.BOLD+' in the main '+color.ORANGE+'Transcriptomes'+color.END+color.BOLD+\
	' Folder'+color.END)

	print (color.BOLD+'\nRe-run '+color.GREEN+'this script (1_FilterTranscripts.py)'+\
	color.END+color.BOLD+' with only the'+color.ORANGE+' --rRNA '+color.END+color.BOLD+\
	'flag\nor the '+color.ORANGE+'--rRNA --BvE '+color.END+color.BOLD+'flags set!'+color.END)
	print(color.BOLD+'\nSee the '+color.RED+'example below'+color.END+color.BOLD+', using '\
	'the output file of this script.'+color.END)

	print(color.BOLD+color.CYAN+'\n   python 1_FilterTranscripts.py --input_file ../'+\
	output_file+'.'+str(minlen)+'bp.fasta --rRNA --BvE --stringency high\n'+color.END)

###########################################################################################
###-------------------------- Cleans Up the PostAssembly Folder ------------------------###
###########################################################################################

def size_clean_up(input_file, output_file, minlen):

	if 'Original' not in input_file.split('/')[-1]:
		renamed_input = input_file.split('/')[-1].split('.fa')[0]+'.Original.fasta'
	else:
		renamed_input = input_file.split('/')[-1]
	
	os.system('mv '+input_file+' ../'+output_file+'/Original/'+renamed_input)


#-----------------------------------------------------------------------------------------#
#------------------------------- rRNA-Based Filtering Steps ------------------------------#
#-----------------------------------------------------------------------------------------#

###########################################################################################
###---------------------- Uses BLAST to identify SSU/LSU Sequences ---------------------###
###########################################################################################

def rRNA_blastn(rRNA_input, threads, rRNAout_folder):

	blastn_out = rRNAout_folder+'/rRNA_Removal/SpreadSheets/'+'.'.join(rRNA_input.split('/')[-1]\
	.split('bp.fasta')[0].split('.')[:-1])+'_allSSULSUresults.tsv'

	BLASTN_cmd = 'blastn -query '+rRNA_input+' -evalue 1e-10 -max_target_seqs 1 -outfmt'\
	' 6 -db ../../Databases/db_BvsE/SSULSUdb -num_threads '+threads+' -out '+blastn_out

	print (color.BOLD+'\n'+'#'*70+'\n'+color.END)
	print (color.BOLD+'BLASTing '+color.DARKCYAN+rRNA_input.split('/')[-1]+color.END\
	+color.BOLD+ ' against the rDNA database' + color.END)
	print (color.BOLD+'\n'+'#'*70+'\n'+color.END)
	os.system(BLASTN_cmd)
	
	return blastn_out


###########################################################################################
###---------------------- Sorts and Isolates the SSU/LSU Sequences ---------------------###
###########################################################################################

def rRNA_parse_hits(rRNA_input, threads, rRNAout_folder):
	
	blastn_out = rRNA_blastn(rRNA_input, threads, rRNAout_folder)

	print (color.BOLD+'Binning Sequences from '+color.DARKCYAN+rRNA_input.split('/')[-1]\
	+color.END+color.BOLD+'\nas '+color.RED+'rRNA'+color.END+color.BOLD+' or '+color.ORANGE+\
	'Potentially Protein-Coding'+color.END)
	print (color.BOLD+'\n'+'#'*70+'\n'+color.END)
		
	rDNA_Hits = list(set([i.split('\t')[0] for i in open(blastn_out).read().split('\n') if i != '']))

	inFasta = [seq_rec for seq_rec in SeqIO.parse(rRNA_input,'fasta')]

	with_SSULSU = "{:,}".format(len(rDNA_Hits))
	no_SSULSU = "{:,}".format(len(inFasta) - len(rDNA_Hits))

	rRNA_seqs = blastn_out.replace('SpreadSheets/','').replace('_allSSULSUresults.tsv','_rRNAseqs.fasta')
	no_rRNA_seqs = rRNA_seqs.replace('_rRNAseqs','_NorRNAseqs')

	with open(rRNA_seqs,'w+') as HasSSU:
		for i in inFasta:
			if i.description in rDNA_Hits:
				HasSSU.write('>'+i.description+'\n'+str(i.seq)+'\n')

	with open(no_rRNA_seqs,'w+') as NoSSU:
		for i in inFasta:
			if i.description not in rDNA_Hits:
				NoSSU.write('>'+i.description+'\n'+str(i.seq)+'\n')

	print (color.BOLD+'There are '+color.RED+with_SSULSU+' rRNA '+color.END+color.BOLD+\
	'contigs'+color.END+color.BOLD+' and '+color.ORANGE+no_SSULSU+' Putative Protein-coding '\
	+color.END+color.BOLD+'\ncontigs in '+color.DARKCYAN+rRNA_input.split('/')[-1]+color.END)
	
	return no_rRNA_seqs

###########################################################################################
###-------------------------------- Next Script Message --------------------------------###
###########################################################################################

def rRNA_next_script(no_rRNA_seqs):

	rRNA_home = no_rRNA_seqs.split('/')[1]

	print (color.BOLD+'\n'+'#'*70+'\n'+color.END)

	print (color.BOLD+'Look for '+color.DARKCYAN+no_rRNA_seqs.split('/')[-1]+color.END+color.BOLD+\
	' in the '+color.ORANGE+rRNA_home.strip('../')+color.END+color.BOLD+' Folder'+color.END)

	print (color.BOLD+'\nRe-run '+color.GREEN+'this script (1t_FilterTranscripts.py)'+\
	color.END+color.BOLD+' with only the'+color.ORANGE+' --BvE '+color.END+color.BOLD+\
	'flag set!'+color.END)
	print(color.BOLD+'\nSee the '+color.RED+'example below'+color.END+color.BOLD+', using '\
	'the output file of this script.'+color.END)

	print(color.BOLD+color.CYAN+'\n   python 1t_FilterTranscripts.py --input_file '+\
	no_rRNA_seqs+' --BvE --stringency high\n'+color.END)


#-----------------------------------------------------------------------------------------#
#--------------- Eukaryotic vs Bacterial/Archaeal Protein Filtering Steps ----------------#
#-----------------------------------------------------------------------------------------#


def BvE_ublast(BvE_input, BvE_folder):

	mic_output = BvE_folder+'/SpreadSheets/'+BvE_input.split('/')[-1].split('fasta')[0]+'micresults.'
	euk_output = mic_output.replace('micresults.','eukresults.')
	
	print (color.BOLD+'\n'+'#'*70+'\n'+color.END)

	print (color.BOLD+'Preparing to compare '+color.DARKCYAN+BvE_input.split('/')[-1]\
	+color.END+color.BOLD+'\nagainst Eukaryotic and Prokaryotic '+color.RED+'protein databases'\
	+color.END)
	print (color.BOLD+'\n'+'#'*70+color.END)

	for n in range(15):
		print (color.BOLD+'\n\n"UBlast"-ing against PROK database: '+color.DARKCYAN+\
		'micout'+str(n)+'.udb'+color.END+'\n\n')

		Prok_usearch_cmd = 'usearch -ublast '+BvE_input+' -maxaccepts 1 -db ../../Databases/'\
		'db_BvsE/micout'+str(n)+'.udb -evalue 1e-5 -blast6out '+mic_output+str(n)

		os.system(Prok_usearch_cmd)

	for n in range(9):
		print (color.BOLD+'\n\n"UBlast"-ing against EUK database: '+color.DARKCYAN+\
		'eukout'+str(n)+'.udb'+color.END+'\n\n')

		Euk_usearch_cmd = 'usearch -ublast '+BvE_input+' -maxaccepts 1 -db ../../Databases/'\
		'db_BvsE/eukout'+str(n)+'.udb -evalue 1e-5 -blast6out '+euk_output+str(n)

		os.system(Euk_usearch_cmd)


	os.system('cat '+mic_output+'* > '+mic_output.split('micresults')[0]+'all_micresults')
	os.system('cat '+euk_output+'* > '+euk_output.split('eukresults')[0]+'all_eukresults')
	os.system('rm '+BvE_folder+'/SpreadSheets/*results.*')

	return mic_output.split('micresults')[0]+'all_micresults', euk_output.split('eukresults')[0]+'all_eukresults'


###########################################################################################
###------------- Sorts and Isolates Strongly Bacterial/Archaeal Sequences --------------###
###########################################################################################

def BvE_parse_hits(BvE_input, BvE_folder, stringency):	

	mic_results, euk_results = BvE_ublast(BvE_input, BvE_folder)

	EukDict = {}
	ProkDict = {}
	CompDict = {}	

	inFasta = [seq_rec for seq_rec in SeqIO.parse(BvE_input, 'fasta')]

	for seq_rec in inFasta:
			EukDict[seq_rec.description] = ''
			ProkDict[seq_rec.description] = ''
			CompDict[seq_rec.description] = []

	inEukHits = [i for i in open(euk_results).readlines()]
	inEukHits.sort(key=lambda x: (float(x.split('\t')[-2]), -int(x.split('\t')[3])))	
	inProkHits = [i for i in open(mic_results).readlines()]
	inProkHits.sort(key=lambda x: (float(x.split('\t')[-2]), -int(x.split('\t')[3])))	

	for i in inEukHits:
		if EukDict[i.split('\t')[0]] == '':
			EukDict[i.split('\t')[0]] = float(i.split('\t')[-2])	

	for i in inProkHits:
		if ProkDict[i.split('\t')[0]] == '':
			ProkDict[i.split('\t')[0]] = float(i.split('\t')[-2])	

	for k in CompDict.keys():
		if EukDict[k] != '':
			CompDict[k].append(EukDict[k])
		else:
			CompDict[k].append('no hit')

		if ProkDict[k] != '':
			CompDict[k].append(ProkDict[k])
		else:
			CompDict[k].append('no hit')

	for k, v in CompDict.items():
	### Contigs lacking STRONG Eukaryotic OR Prokaryotic Hits
		if v[0] == 'no hit' and v[1] == 'no hit':
			CompDict[k].append('UNDETERMINED')
	### Contigs lacking STRONG Eukaryotic with a Prokaryotic Hit	
		elif v[0] != 'no hit' and v[1] == 'no hit':
			CompDict[k].append('EUKARYOTIC')
	### Contigs with a Eukaryotic but without a Prokaryotic Hit		
		elif v[0] == 'no hit' and v[1] != 'no hit':
			CompDict[k].append('PROKARYOTIC')
	### Uses Basic math to determine if contigs with are MORE Eukaryotic than Prokaryotic				
		else:
			try:
				prok_euk_ratio = float(v[1])/float(v[0])
				euk_prok_ratio = float(v[0])/float(v[1])

				if prok_euk_ratio >= 100:
					CompDict[k].append('EUKARYOTIC')

				elif  euk_prok_ratio >= 1000 and stringency == "high":
					CompDict[k].append('PROKARYOTIC')

				elif  euk_prok_ratio >= 10000 and stringency == "low":
					CompDict[k].append('PROKARYOTIC')

				elif stringency.isdigit() == True:
					if euk_prok_ratio >= int(stringency):
						CompDict[k].append('PROKARYOTIC')				

				else:
					CompDict[k].append('UNDETERMINED')

			except:
				CompDict[k].append('divide by zero')
	
	
	
	with open(mic_results.split('.all_micresults')[0]+'.BvE_Comparisons.txt','w+') as w:
		for k, v in CompDict.items():
			w.write(k+':'+':'.join([str(i) for i in v])+'\n')
	
	return CompDict, inFasta
		
###########################################################################################
###------------- Categorizes the Sequence Data and Writes Them Out to File -------------###
###########################################################################################

def BvE_final_fasta(comp_dict, infasta, BvEout_base, BvE_input):	

### Gathers the sequences and categorizes them	
	Euk_Fasta = sorted((i for i in infasta if comp_dict[i.description][-1] == 'EUKARYOTIC'), key=lambda x: -int(len(x.seq)))
	Prok_Fasta = sorted((i for i in infasta if comp_dict[i.description][-1] == 'PROKARYOTIC'), key=lambda x: -int(len(x.seq)))
	Und_Fasta = sorted((i for i in infasta if comp_dict[i.description][-1] == 'UNDETERMINED'), key=lambda x: -int(len(x.seq)))
	Zero_Fasta = sorted((i for i in infasta if comp_dict[i.description][-1] == 'divide by zero'), key=lambda x: -int(len(x.seq)))

	NBU_Fasta = Euk_Fasta + Und_Fasta
	NBU_Fasta.sort(key=lambda x: -int(len(x.seq)))

	Prok_Contigs = len(set(Prok_Fasta))
	Euk_Contigs = len(set(Euk_Fasta))
	Und_Contigs = len(set(Und_Fasta))
	
	
### Writes out all of the categorized sequences
	with open(BvEout_base+'Euk_Hit.fasta','w+') as nb:
		for euk_seq in Euk_Fasta:
			nb.write('>'+euk_seq.description+'\n'+str(euk_seq.seq)+'\n')	
			Euk_Contigs += 1

	with open(BvEout_base+'Bact_Hit.fasta','w+') as pr:
		for prok_seq in Prok_Fasta:
			pr.write('>'+prok_seq.description+'\n'+str(prok_seq.seq)+'\n')		
			Prok_Contigs += 1
			
	with open(BvEout_base+'Undetermined.fasta','w+') as und:
		for und_seq in Und_Fasta:
			und.write('>'+und_seq.description+'\n'+str(und_seq.seq)+'\n')
			Und_Contigs += 1
			
	with open(BvEout_base+'WTA_NBU.fasta','w+') as nbu:
		for nbu_seq in NBU_Fasta:
			nbu.write('>'+nbu_seq.description+'\n'+str(nbu_seq.seq)+'\n')

	if len(Zero_Fasta) != 0:
		with open(BvEout_base+'DivideByZero.fas','w+') as w:
			for zero_seq in Zero_Fasta:
				w.write('>'+zero_seq.description+'\n'+str(zero_seq.seq)+'\n')
				Prok_Contigs += 1
	else:
		pass			

	print (color.BOLD+'\n'+'#'*70+'\n\nThere are '+color.RED+"{:,}".format(Prok_Contigs)+\
	' Strongly Prokaryotic contigs'+color.END+color.BOLD+',\n'+color.ORANGE+"{:,}".format(Euk_Contigs)+\
	' Strongly Eukaryotic contigs'+color.END+color.BOLD+',\nand '+color.PURPLE+"{:,}"\
	.format(Und_Contigs)+' Undetermined Contigs\n'+color.END+color.BOLD+'in: '+\
	color.DARKCYAN+BvE_input.split('/')[-1]+color.END)


###########################################################################################
###-------------------------------- Next Script Message --------------------------------###
###########################################################################################

def BvE_next_script(BvEout_base):

	BvE_home = BvEout_base.split('/')[1]
	BvE_final_out = BvEout_base.split('/')[-1]+'WTA_NBU.fasta'

	print (color.BOLD+'\n'+'#'*70+'\n'+color.END)

	print (color.BOLD+'Look for '+color.DARKCYAN+BvE_final_out+color.END+color.BOLD+\
	' in the '+color.ORANGE+BvE_home+color.END+color.BOLD+' Folder'+color.END)


	print (color.BOLD+'\nNext Script is: '+color.GREEN+'2t_MapToOGs.py'+color.END)
	print(color.BOLD+'\nSee the '+color.RED+'example below'+color.END+color.BOLD+', using '\
	'the output file of this script.'+color.END)
	
	print(color.BOLD+color.CYAN+'\n   python 2t_MapToOGs.py --input_file '+BvEout_base+\
	'WTA_NBU.fasta\n'+color.END)


###########################################################################################
#-----------------------------------------------------------------------------------------#
#---------------------- Three Major Methods Controlling Data Output ----------------------#
#-----------------------------------------------------------------------------------------#
###########################################################################################

def size_filt(args):

	prep_folders(args)
	
	renamed_seqs, seq_code_dict = size_RemoveShort(args.input_file, int(args.minlen), args.genbank, args.spades)
	
	size_WriteDataOut(renamed_seqs, seq_code_dict, args.output_file, args.minlen, args.genbank, args.spades)
	
	if args.rRNA == False and args.BvE == False:
		size_next_script(args.output_file, args.minlen)
	
	size_clean_up(args.input_file, args.output_file, args.minlen)


def rRNA_filt(args):

	check_rRNA_db()

	prep_folders(args)
	
	no_rRNA_seqs = rRNA_parse_hits(args.rRNA_input, args.threads, args.rRNAout_folder)

	if args.BvE == False:
		rRNA_next_script(no_rRNA_seqs)

		
def BvE_filt(args):

	check_BvE_db()

	prep_folders(args)
	
	Comparisons, inFasta = BvE_parse_hits(args.BvE_input, args.BvEout_folder, args.stringency)
	
	BvEout_base = args.BvEout_folder+args.BvE_input.split('/')[-1].split('NorRNAseqs')[0]
	
	BvE_final_fasta(Comparisons, inFasta, BvEout_base, args.BvE_input)

	BvE_next_script(BvEout_base)

	
def main():

	start = time.time()
	
	args = check_args()
	
	if args.size == True:
		size_filt(args)
	
	if args.rRNA == True:
		rRNA_filt(args)

	if args.BvE == True:
		BvE_filt(args)
	
	end = time.time()

	hours, rem = divmod(end-start, 3600)
	minutes, seconds = divmod(rem, 60)
	print(color.BOLD+'Total Running Time:   \t'+"{:0>2}:{:0>2}:{:05.2f}".format(int(hours),int(minutes),seconds)+'\n'+color.END)

		
main()