#!/usr/bin/env python3

##__Updated__: 04_02_2018
##__Author__: Xyrus Maurer-Alcalá; maurerax@gmail.com; xyrus.maurer-alcala@izb.unibe.ch
##__Usage__: python 2_MapToOGs.py
##__Options__: python 2_MapToOGs.py --help


###########################################################################################
## This script is intended to classify the STRONGLY Eukaryotic and UNDETERMINED/UNKNOWN  ##
## contigs into different OGs (e.g. orthologous gene-families)                           ##
##                                                                                       ##
## For more info about the OGs, check out: OrthoMCL.org                                  ##
##                                                                                       ##
## Prior to running this script, ensure the following:                                   ##
##                                                                                       ##
## 1. You have assembled your transcriptome and COPIED the 'assembly' file               ##
##    (contigs.fasta, or scaffolds.fasta) to the PostAssembly Folder                     ##
## 2. Removed small sequences (usually sequences < 200bp) with 1_FilterTranscripts.py    ##
## 3. Removed SSU/LSU sequences from your Fasta File with 1_FilterTranscripts.py         ## 
## 4. Enriched for Eukaryotic proteins (1_FilterTranscripts.py)                          ##
##                                                                                       ##
##                       E-mail Xyrus (author) for help if needed                        ##
##                                                                                       ##
###########################################################################################

import argparse, os, shutil, sys, time
from argparse import RawTextHelpFormatter,SUPPRESS
from distutils import spawn
from Bio import SeqIO


#------------------------------ Colors For Print Statements ------------------------------#
class color:
   PURPLE = '\033[95m'
   CYAN = '\033[96m'
   DARKCYAN = '\033[36m'
   ORANGE = '\033[38;5;214m'
   BLUE = '\033[94m'
   GREEN = '\033[92m'
   YELLOW = '\033[93m'
   RED = '\033[91m'
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'

#------------------------------- Main Functions of Script --------------------------------#

###########################################################################################
###-------------------- Checks that the executables are in the PATH --------------------###
###########################################################################################

def validate_executables():
	
	missing_from_path = []

	if shutil.which('usearch') == None:
		missing_from_path.append('USearch')
	
	if len(missing_from_path) > 0:
		print (color.BOLD+color.RED+'\nError'+color.END+color.BOLD+': The following programs '\
		'are missing from your "PATH":\n\n'+color.END)
		for i in missing_from_path:
			print (color.GREEN+'   '+i+color.END+'\n')
		print (color.BOLD+'\nEnsure that they are installed in the PATH prior to running '\
		'this script\n\n'+color.END)
		sys.exit()
	else:
		pass


###########################################################################################
###--------------------- Parses and Checks Command-Line Arguments ----------------------###
###########################################################################################

def check_args():

	parser = argparse.ArgumentParser(description=
	color.BOLD + '\nThis script will categorize Contigs into "'+color.ORANGE+'Homologous'\
	+color.END+color.BOLD+'" Gene\nFamilies (OGs) based on '+color.RED+'OrthoMCL'+color.END\
	+color.BOLD+"'s Gene Family clustering\n\nInformation about "+color.RED+\
	'OrthoMCL'+color.END+color.BOLD+' can be found on their\nwebsite: '+color.CYAN\
	+'http://orthomcl.org/'+color.END+usage_msg(), usage=SUPPRESS,
	formatter_class=RawTextHelpFormatter)
	
	required_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Required Options'+color.END)
 
	required_arg_group.add_argument('--input_file','-in', action='store',
	help=color.BOLD+color.GREEN+'Fasta file of Nucleotide sequences enriched \nwith'\
	' Eukaryotic protein coding transcripts'+color.END)

	optional_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Options'+color.END)
	optional_arg_group.add_argument('--alignment','-a', default='0.5',
	help=color.BOLD+color.GREEN+' Minimum alignment length to "hit" (default: 0.5)\n'+color.END)
	optional_arg_group.add_argument('-author', action='store_true',
	help=color.BOLD+color.GREEN+' Prints author contact information\n'+color.END)

	if len(sys.argv[1:]) == 0:
		print (parser.description)
		print ('\n')
		sys.exit()

	args = parser.parse_args()
	
	args.OG_folder = '../'+args.input_file.split('/')[1]+'/UsearchOG/'
	
	args.out_file = '../'+args.input_file.split('/')[1]+'/UsearchOG/'+args.input_file\
	.split('/')[-1].split('.fas')[0]+'.Renamed.fasta'
	
	if args.author == True:
		print (color.BOLD+color.ORANGE+'\n\n\tQuestions/Comments? Email Xyrus (author) at'\
		' maurerax@gmail.com or xyrus.maurer-alcala@izb.unibe.ch\n\n'+color.END)

	return args

		
###########################################################################################
###------------------------------- Script Usage Message --------------------------------###
###########################################################################################

def usage_msg():
	return (color.BOLD+color.RED+'\n\nExample usage:\n\n'+color.CYAN+'   python 2_MapToOGs.py'\
	' --input_file ../Op_me_Xxma/Op_me_Xxma_WTA_NBU.fasta --alignment 0.35'+color.END)



def check_input(args):

	if args.input_file.endswith('WTA_NBU.fasta') != True or os.path.isfile(args.input_file) != True:
		print ('\n'+color.BOLD+color.RED+'#'*70+'\n'+color.END)
		print (color.BOLD+color.RED+'Error:'+color.END+color.BOLD+': Unexpected issue with '\
		'the input Fasta file.'+color.END+'\n')
		print(color.BOLD+'Please check that the file exists and is properly named\n(must end in'\
		' "'+color.RED+'WTA_NBU.fasta'+color.END+color.BOLD+'"), then try again.\n'+color.END)
		sys.exit()


def check_OG_db():
		
	if os.path.isdir('../../Databases/db_OG') != True:
		print ('\n'+color.BOLD+color.RED+'#'*70+'\n'+color.END)
		print (color.BOLD+color.RED+'Error'+color.END+color.BOLD+': Cannot find the '\
		+color.ORANGE+'db_OG Folder!\n\n'+color.END+color.BOLD+'Ensure that this folder '\
		'can be found in the main '+color.ORANGE+'Databases Folder'+color.END+color.BOLD\
		+'\n\nThen try once again.\n'+color.END)
		sys.exit()
		
	og_out = len([i for i in os.listdir('../../Databases/db_OG/') if 'OGSout' in i])

	quit = 0
	og_exp = 7
	
	if og_out != og_exp:
		print ('\n'+color.BOLD+color.RED+'#'*70+'\n'+color.END)
		print (color.BOLD+color.RED+'Error'+color.END+color.BOLD+': Found '+color.ORANGE+\
		str(og_out)+color.END+color.BOLD+'/'+color.ORANGE+str(og_exp)+color.END+color.BOLD+\
		' of the expected '+color.ORANGE+'O'+color.END+color.BOLD+'rthologous '+color.ORANGE+\
		'G'+color.END+color.BOLD+'ene '+color.ORANGE+'Family databases'+color.END)
		quit += 1
		
	if quit != 0:
		print (color.BOLD+'\nRe-download these using the links provided by the following '+\
		color.CYAN+'GitHub page:\n\n\tgithub.com/maurerax/HTS-Processing-PhyloGenPipeline'\
		+color.END+'\n')
		sys.exit()

	
###########################################################################################
###--------------------------- Does the Inital Folder Prep -----------------------------###
###########################################################################################

def prep_folders(args):

	if os.path.isdir(args.OG_folder) != True:
		os.system('mkdir '+args.OG_folder)

	if os.path.isdir(args.OG_folder+'OG_CompData') != True:
		os.system('mkdir '+args.OG_folder+'OG_CompData')			

		
###########################################################################################
###--------------------- Runs Usearch on Split OrthoMCL Databases ----------------------###
###########################################################################################

def OG_ublast(args):
	
	print ('\n'+color.BOLD+'#'*70+'\n'+color.END)
		
	print (color.BOLD+'Using "UBlast" to compare data (from '+color.DARKCYAN+args.input_file\
	.split('/')[-1]+color.END+color.BOLD+')\nagainst the OG databases'+color.END)
	print ('\n'+color.BOLD+'#'*70+'\n'+color.END)
		
	UBlast_output = args.input_file.split('/')[-1].split('.fas')[0]+'_OGSout'
	
	for n in range(7):
		print (color.BOLD+'\n"UBlast"-ing against OG database: '+color.DARKCYAN+\
		'OGSout'+str(n)+'.udb'+color.END+'\n\n')			
				
		OG_usearch_cmd = 'usearch -ublast '+args.input_file+' -maxaccepts 1'\
		' -db ../../Databases/db_OG/OGSout'+str(n)+'.udb -evalue 1e-10 -target_cov '+\
		args.alignment+' -blast6out '+args.OG_folder+'OG_CompData/'+UBlast_output+str(n)		
		
		os.system(OG_usearch_cmd)
			
			
	os.system('cat '+args.OG_folder+'OG_CompData/*OGSout* > '+args.OG_folder+'OG_CompData/'\
	+args.input_file.split('/')[-1].split('.fas')[0]+'.all_OGresults')
	
	os.system('rm '+args.OG_folder+'OG_CompData/*OGSout*')		


###########################################################################################
###--------------- Keeps the Single BEST Hit (HSP-score) Per Transcript ----------------###
###########################################################################################

def keep_best(args):

	print ('\n'+color.BOLD+'#'*70+'\n'+color.END)
	print (color.BOLD+'Processing OG-database results to keep only the'\
	' '+color.ORANGE+'BEST OG-assignment'+color.END+color.BOLD+'\nfor each transcript.'+color.END)	
		
	OG_tsv = [i for i in open(args.OG_folder+'OG_CompData/'+args.input_file.split('/')[-1]\
	.split('.fas')[0]+'.all_OGresults').read().split('\n') if i != '']
	
	OG_tsv.sort(key = lambda x: -float(x.split('\t')[-1]))
	
	keep = []
	seen = []
	for i in OG_tsv:
		if i.split('\t')[0] not in seen:
			keep.append(i)
			seen.append(i.split('\t')[0])
	
	updated_lines = list(set([line.split('\t')[0]+'_'+'_'.join(line.split('\t')[1].split('_')[-2:])\
	+'\t'+'\t'.join(line.split('\t')[1:]) for line in keep]))
		
	with open(args.out_file.replace('.fasta','.OGresults.tsv'), 'w+') as w:
		w.write('\n'.join(updated_lines))	

	return args.out_file.replace('.fasta','.OGresults.tsv')

###########################################################################################
###-------- Copies and Updates Names of Transcripts With OG Hits to New Fasta ----------###
###########################################################################################

def finalize_fasta(args):

	final_tsv = keep_best(args)

	print ('\n'+color.BOLD+'#'*70+'\n'+color.END)
	print (color.BOLD+'Collecting and updating the sequences with their '+color.ORANGE+'OG-assignments'\
	+color.END+'\n')

	keep = [i for i in open(final_tsv).read().split('\n') if i != '\n']

	keep_dict = {line.split('\t')[0].split('_OG5')[0]:line.split('\t')[0].split('_OG5')[0]+'_OG5_'\
	+line.split('\t')[1].split('_')[-1] for line in keep if 'OG5' in line.split('\t')[1]}
	
	inFasta = [i for i in SeqIO.parse(args.input_file,'fasta')]
	
	updated_seq_name = ['>'+keep_dict[i.description]+'\n'+str(i.seq)+'\n' for i in inFasta if i.description in keep_dict.keys()]

	seqs_without_OG = ['>'+i.description+'\n'+str(i.seq)+'\n' for i in inFasta if i.description not in keep_dict.keys()]
	
	unique_og = len(list(set([i.split('_')[-1].split('\n')[0] for i in updated_seq_name])))
	
	print (color.BOLD+'#'*70+'\n\nThere are '+color.RED+"{:,}".format(len(updated_seq_name))+\
	color.END+color.BOLD+' transcipts hitting '+color.RED+"{:,}".format(unique_og)+color.END+\
	color.BOLD+' unique OGs,\nand '+color.PURPLE+"{:,}".format(len(seqs_without_OG))+color.END+\
	color.BOLD+' transcripts '+color.PURPLE+'lacking'+color.END+color.BOLD+' an OG assignment\n'+\
	'in: '+color.DARKCYAN+args.input_file.split('/')[-1]+color.END+'\n')

	with open(args.out_file,'w+') as w:
		for i in updated_seq_name:
			w.write(i)		

	with open(args.out_file.replace('.fasta','.LackOG.fasta'),'w+') as x:
		for i in seqs_without_OG:
			x.write(i)		
			

###########################################################################################
###-------------------------------- Next Script Message --------------------------------###
###########################################################################################

def next_script(args):

	print (color.BOLD+'\n'+'#'*70+'\n'+color.END)

	print (color.BOLD+'Look for '+color.DARKCYAN+args.out_file.split('/')[-1]+color.END+\
	color.BOLD+' in the\n'+color.ORANGE+'/'.join(args.OG_folder.split('/')[1:])+color.END+\
	color.BOLD+' folder.'+color.END)

	print (color.BOLD+'\nNext Script is: '+color.GREEN+'3t_CallORFs.py'+color.END)
	print(color.BOLD+'\nSee the '+color.RED+'examples below'+color.END+color.BOLD+', using '\
	'the output file of this script.'+color.END)

	print(color.BOLD+color.RED+'\nTo evaluate the genetic code (unknown genetic code usage)'\
	+color.END+color.BOLD+':\n\n'+color.CYAN+'   python 3t_CallORFs.py --input_file '+args\
	.out_file+' --evaluate\n'+color.END)

	print(color.BOLD+color.RED+'\nSlower/more accurate option (known genetic code usage)'+color.END\
	+color.BOLD+':\n\n'+color.CYAN+'   python 3t_CallORFs.py --input_file '+args.out_file+\
	' --align --genetic_code SOME_CODE_HERE --clean\n'+color.END)

	print(color.BOLD+color.RED+'\nVery fast option (known genetic code usage)'+color.END\
	+color.BOLD+':\n\n'+color.CYAN+'   python 3t_CallORFs.py --input_file '+args.out_file+\
	' --genetic_code SOME_CODE_HERE --blind --clean\n'+color.END)

	

###########################################################################################
###--------------- Checks Command Line Arguments and Calls on Functions ----------------###
###########################################################################################
				
def main():

	start = time.time()

	validate_executables()

	args = check_args()
	
	check_OG_db()

	check_input(args)

	prep_folders(args)

	OG_ublast(args)

	finalize_fasta(args)

	next_script(args)

	end = time.time()
		
	hours, rem = divmod(end-start, 3600)
	minutes, seconds = divmod(rem, 60)
	print(color.BOLD+'\nTotal Running Time:   \t'+"{:0>2}:{:0>2}:{:05.2f}".format(int(hours),int(minutes),seconds)+'\n'+color.END)


main()
