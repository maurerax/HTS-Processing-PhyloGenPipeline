#!/usr/bin/env python

from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Data.CodonTable import CodonTable
from Bio.Emboss.Applications import WaterCommandline
import os, sys, argparse, time, shutil
from argparse import RawTextHelpFormatter,SUPPRESS


#-------------------------- Set-up Codon Tables (Genetic Codes) --------------------------#

blepharisma_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y',                       
	'TGT': 'C', 'TGC': 'C', 'TGA': 'W', 'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = ['TAA','TAG'])

condylostoma_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y', 'TAA': 'Q', 'TAG': 'Q',
	'TGT': 'C', 'TGC': 'C', 'TGA': 'W', 'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = [''])

c_uncinata_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y',             'TAG': 'Q',
	'TGT': 'C', 'TGC': 'C', 'TGA': 'Q', 'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = ['TAA'])

euplotes_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y',                       
	'TGT': 'C', 'TGC': 'C', 'TGA': 'C', 'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = ['TAA','TAG'])

myrionecta_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y', 'TAA': 'Y', 'TAG': 'Y',
	'TGT': 'C', 'TGC': 'C',             'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = ['TGA'])

no_stop_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y', 'TAA': 'X', 'TAG': 'X',
	'TGT': 'C', 'TGC': 'C', 'TGA': 'X', 'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = [''])

peritrich_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y', 'TAA': 'E', 'TAG': 'E',
	'TGT': 'C', 'TGC': 'C',             'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = ['TGA'])
	
tag_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y', 'TAA': 'Q',            
	'TGT': 'C', 'TGC': 'C', 'TGA': 'Q', 'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = ['TAG'])


#------------------------------ Colors For Print Statements ------------------------------#
class color:
   PURPLE = '\033[95m'
   CYAN = '\033[96m'
   DARKCYAN = '\033[36m'
   ORANGE = '\033[38;5;214m'
   PURPLE = '\033[94m'
   GREEN = '\033[92m'
   YELLOW = '\033[93m'
   RED = '\033[91m'
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'


#------------------------------- Main Functions of Script --------------------------------#

###########################################################################################
###--------------------- Parses and Checks Command-Line Arguments ----------------------###
###########################################################################################

def check_args():

	parser = argparse.ArgumentParser(description=
	color.BOLD+'\nThis script will extract '+color.ORANGE+'ALL NUCLEOTIDE ORFs'+color.END+color.BOLD+\
	' from a transcriptome.\n\nNote that this is done through '+color.BOLD+color.RED+\
	'pair-wise alignments'+color.END+color.BOLD+' comparing the transcript\nto the corresponding '\
	+color.BOLD+color.RED+'OG-database "hit"'+color.END+color.BOLD+'.'+color.END+usage_msg(), 
	usage=SUPPRESS,formatter_class=RawTextHelpFormatter)
	
	required_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Required Options'+color.END)

	required_arg_group.add_argument('--input_file','-in', action='store',
	help=color.BOLD+color.GREEN+" Fasta file of transcripts\n"+color.END)

	optional_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Options'+color.END)

	optional_arg_group.add_argument('--evaluate','-e', action='store_true',
	help=color.BOLD+color.GREEN+' Evaluates the presence and abundance of in-Frame\n termination codons'\
	' (i.e. Non-canonical genetic codes)\n'+color.END)

	optional_arg_group.add_argument('--genetic_code','-g', action='store', default=None,
	help=color.BOLD+color.GREEN+' Genetic code to use for translation\n'+color.END)

	optional_arg_group.add_argument('--skip_water','-sw', action='store_true', default=False,
	help=color.BOLD+color.GREEN+' Skips "water" alignments if previously performed\n'+color.END)
	
	optional_arg_group.add_argument('--list_codes','-codes', action='store_true',
	help=color.BOLD+color.GREEN+' Lists supported genetic codes\n'+color.END)

	optional_arg_group.add_argument('--cleaner','-clean', action='store_true',
	help=color.BOLD+color.GREEN+' Will remove the temporary alignment files and directory\n'+color.END)


	optional_arg_group.add_argument('-author', action='store_true',
	help=color.BOLD+color.GREEN+' Print author contact information\n'+color.END)
	

	if len(sys.argv[1:]) == 0:
		print (parser.description)
		print ('\n')
		sys.exit()

	args = parser.parse_args()
	
	quit_eval = return_more_info(args)
	if quit_eval > 0:
		sys.exit()

	args.tsv_file = args.input_file.replace('.fasta','_allOGCleanresults.tsv')
	args.og_db = '../../Databases/db_OG/AllOGs.fasta'
	
	quit_eval = return_more_info(args)
	if quit_eval > 0:
		sys.exit()

	if args.genetic_code != None:
		args.nuc_out = args.input_file.split('.fas')[0]+'.'+args.genetic_code.title()+'.NTD.fasta'
		args.prot_out = args.nuc_out.replace('.NTD', '.AA')	

	args.home_folder = '/'.join(args.input_file.split('/')[:-1])
	args.Usearch_Folder = '../'+args.input_file.split('/')[1]+'/UsearchOG'
	args.storage = args.home_folder+'/temp_water_storage'
		
	return args


###########################################################################################
###------------------------------- Script Usage Message --------------------------------###
###########################################################################################

def usage_msg():
	return (color.BOLD+color.RED+'\n\nExample usage (evaluating genetic code):\n'+color.CYAN+'python ExtractORFs.py'\
	' --input_file ../Op_me_Xxma/Op_me_Xxma_WTA_NBU.Renamed.fasta --evaluate\n\n'+color.RED+'Example usage'\
	' (with known genetic code):\n'+color.CYAN+'python ExtractORFs.py --input_file '\
	'../Op_me_Xxma/Op_me_Xxma_WTA_NBU.Renamed.fasta --genetic_code universal'+color.END)


##########################################################################################
###-------- Storage for LARGE (Annoying) Print Statements for Flagged Options ---------###
##########################################################################################

def return_more_info(args):

	valid_arg = 0

	author = (color.BOLD+color.ORANGE+'\n\n         Questions/Comments? Email Xyrus (author)\n'\
	+color.PURPLE+'\n   maurerax@gmail.com or xyrus.maurer-alcala@izb.unibe.ch\n\n'+color.END)

	if args.author == True:
		print (author)
		valid_arg += 1
	
	return valid_arg
	
	
###########################################################################################
###--------------------------- Does the Inital Folder Prep -----------------------------###
###########################################################################################

def prep_folders(args):

	if os.path.isdir(args.storage) != True:
		os.system('mkdir '+args.storage)


###########################################################################################
###---------------- Checks the location of "water" and the OG database -----------------###
###########################################################################################

def check_paths(args):
	
	fail = 0
	
	water = shutil.which('water')
		
	og_db = os.path.isfile(args.og_db)
	
	if water == None:
		print (color.BOLD+color.RED+'#'*70+'\n\nError: "water" (from the EMBOSS package) is not in your path.\n'\
		+color.END+color.BOLD+'Please install EMBOSS and put the packages into your path\n'+color.END)
		fail += 1
		
	if og_db == False:
		print (color.BOLD+color.RED+'#'*70+'\n\nError: OG database (AllOGs.fasta) was not found.\n'\
		+color.END+color.BOLD+'Ensure that you are running THIS script from the '+color.PURPLE+\
		'\n"Transcriptomes/Scripts"'+color.END+color.BOLD+' folder and that '+color.ORANGE+'AllOGs.fasta'\
		+color.END+color.BOLD+'\nis in the db_OG folder (in the databases folder)\n'+color.END)
		fail += 1
	
	if fail != 0:
		sys.exit()

		
##########################################################################################
###--------------------- Makes Translation Steps (Later) Easier -----------------------###
##########################################################################################

def standardize_gcode(given_code):
	if given_code == 'ciliate' or given_code == 'tga':
		codon_table = 6
		print (color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END)	

	elif given_code == 'chilodonella' or given_code == 'chilo' or given_code == 'taa':
		codon_table = c_uncinata_table
		print (color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END)	

	elif given_code == 'blepharisma' or given_code == 'bleph':
		codon_table = blepharisma_table
		print (color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END)	

	elif given_code == 'euplotes' or given_code == 'eup':
		codon_table = euplotes_table
		print (color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END)	

	elif given_code == 'myrionecta' or given_code == 'mesodinium':
		codon_table = myrionecta_table
		print (color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END)	

	elif given_code == 'peritrich' or given_code == 'vorticella':
		codon_table = peritrich_table
		print (color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END)	

	elif given_code == 'none':
		codon_table = no_stop_table
		print (color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END)	

	elif given_code == 'condylostoma' or given_code == 'condy':
		codon_table = condylostoma_table
		print (color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END)	

	elif given_code == 'tag':
		codon_table = tag_table
		print (color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END)	

	elif given_code == 'universal':
		codon_table = 1
		print (color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END)	

	else:
		print (color.BOLD+color.RED+'\nNo valid genetic code provided!\n\n'+color.END+\
		color.BOLD+'Translating all stop codons as '+color.PURPLE+'"X" (by default)'\
		+color.END+color.BOLD+'\n\nPlease check that the code you wish to use is supported:'\
		+color.CYAN+'\n\npython 5_GCodeTranslate.py -list_codes'+color.END)
		codon_table = no_stop_table

	return codon_table
	

###########################################################################################
###----------------------------- Breaks ORF Into Codons --------------------------------###
###########################################################################################

def SplitByCodon(given_seq):
	codons = [given_seq[n:n+3] for n in range(0, len(given_seq),3)]
	return codons
	

###########################################################################################
###---------------------- Prepares Transcripts (and Hit Sequence) ----------------------###
###########################################################################################

def prep_sequences(args, codon_table):
	
	intsv = [i for i in open(args.tsv_file).read().split('\n') if i != '']
	
	print (color.BOLD+'\n\nGathering transcripts from:  '+color.GREEN+args.input_file.split('/')[-1]+color.END)
	
	infasta = {i.description:str(i.seq) for i in SeqIO.parse(args.input_file,'fasta')}

	coords = {'\t'.join(i.split('\t')[:2]):[i.split('\t')[6],i.split('\t')[7]] for i in intsv}

	og_hits = list(set([k.split('\t')[-1] for k in coords.keys()]))

	if args.skip_water == False:
		print (color.BOLD+'\n\nCollecting "hits" to representative OG-database. '\
		'This can take a while.'+color.END)
		ogfasta = {i.description:str(i.seq) for i in SeqIO.parse(args.og_db,'fasta') if i.description in og_hits}

	else:
		pass

	for k, v in coords.items():
		orig_seq = infasta[k.split('\t')[0]]
		seq_len = int(k.split('Len')[1].split('_')[0])

		if int(v[1]) > int(v[0]):
			start_pos = int(v[0])
			if start_pos%3 != 0:
				cut = (start_pos)%3-1
			else:
				cut = 2
			if (seq_len-cut)%3 != 0:
				end_pos = -((seq_len-cut)%3)
			else:
				end_pos = None

			coords[k].append(str(Seq(orig_seq)[cut:end_pos].translate(table=codon_table)).replace('*','X'))
			coords[k].append(str(orig_seq[cut:end_pos]))

			if args.skip_water == False:
				coords[k].append(ogfasta[k.split('\t')[-1]])				

		elif int(v[0]) > int(v[1]):
			start_pos = int(v[0])
			cut = (seq_len - start_pos)%3

			if (seq_len-cut)%3 != 0:
				end_pos = -((seq_len-cut)%3)
			else:
				end_pos = None

			coords[k].append(str(Seq(orig_seq).reverse_complement()[cut:end_pos].translate(table=codon_table)).replace('*','X'))
			coords[k].append(str(Seq(orig_seq).reverse_complement()[cut:end_pos]))

			if args.skip_water == False:
				coords[k].append(ogfasta[k.split('\t')[-1]])				

	return coords


###########################################################################################
###---------------------- Performs the "water" alignment (Emboss) ----------------------###
###########################################################################################

def water_align2(coords, args):
	total_comparisons = str(len(coords))
	count = 0
	errors = []
	for k, v in coords.items():

		with open(args.storage+'/seq1','w+') as w:
			w.write('>'+k.split('\t')[0]+'\n'+v[2])

		with open(args.storage+'/seq2','w+') as x:
			x.write('>'+k.split('\t')[1]+'\n'+v[-1])	

		water_cline = WaterCommandline("water",asequence=args.storage+'/seq1',bsequence=args.storage+'/seq2'\
		,gapopen=10, gapextend=0.5, outfile=args.storage+'/'+k.replace('\t','_')+'.water')
		
		try:
			stdout, stderr = water_cline()
		except:
			errors.append(k)
				
		count += 1

		print (color.BOLD+'Pairs Aligned: '+color.DARKCYAN+str(count)+'/'+total_comparisons+\
		color.END, end = '\t\t\r')			
	
	print (color.BOLD+'Pairs Aligned: '+color.DARKCYAN+str(count)+'/'+total_comparisons+\
		'\n'+color.END)
	print (color.BOLD+'#'*70+'\n'+color.END)


def water_align(coords, args): ### water_align2 fails on 1243
	total_comparisons = str(len(coords))
	count = 0
	
	for k, v in coords.items():

		with open(args.storage+'/seq1','w+') as w:
			w.write('>'+k.split('\t')[0]+'\n'+v[2])

		with open(args.storage+'/seq2','w+') as x:
			x.write('>'+k.split('\t')[1]+'\n'+v[-1])	

		water_cmd = 'water -asequence '+args.storage+'/seq1 -bsequence '+args.storage+'/seq2'\
		' -gapopen 10 -gapextend 0.5 -outfile '+args.storage+'/'+k.replace('\t','_')+'.water'	

		os.system(water_cmd)
		count += 1

		print (color.BOLD+'Pairs Aligned: '+color.DARKCYAN+str(count)+'/'+total_comparisons+\
		color.END)
	
	print (color.BOLD+'#'*70+'\n'+color.END)
		

###########################################################################################
###-------------- Checks for Alternative Upstream "Start" Codon Positions --------------###
###########################################################################################

def check_5prime(prot_seq, initial_coord_hit):

	methionine_start = [pos for pos in [s for s, i in enumerate(prot_seq) if i == 'M'] if pos < initial_coord_hit]
	stop_codons_early = [pos for pos in [s for s, i in enumerate(prot_seq) if i == 'X'] if pos < initial_coord_hit]

	if len(methionine_start) == 0:
		methionine_start = initial_coord_hit-1
	else:
		methionine_start = methionine_start[-1]	

	if len(stop_codons_early) == 0:
		pass
	else:
		stop_codons_early = stop_codons_early[-1]	
		if stop_codons_early > methionine_start:
			methionine_start = initial_coord_hit-1

	return methionine_start


###########################################################################################
###------------ Checks for Downstream "Stop" Codons with Given Genetic Code ------------###
###########################################################################################

def check_3prime(prot_seq, end_coord_hit, args):
	if args.evaluate == False:
		stop_codons_late = [pos for pos in [s for s, i in enumerate(prot_seq) if i == 'X'] if pos >= end_coord_hit]

		if len(stop_codons_late) != 0:
			stop_codons_late = stop_codons_late[0]
			terminate = 'y'
		else:
			stop_codons_late = end_coord_hit
			terminate = 'n'

	else:
		stop_codons_late = end_coord_hit
		terminate = 'n'
	return stop_codons_late, terminate
	

###########################################################################################
###------------------ Extracts ORFs from Alignment Based Measurements ------------------###
###########################################################################################

def post_water_ORF_extract(coords, args):

	time.sleep(1)
	
	keys_bad = []

	for k, v in coords.items():
		water_name = args.storage+'/'+k.replace('\t','_')+'.water'		

		if os.path.isfile(water_name) != True:
			keys_bad.append(k)
			continue

		in_water = [i for i in open(water_name).read().split('\n') if i != '']
		initial_coord_hit = int([j for j in [i for i in in_water if i.startswith(water_name.split('/')[-1][:8])][0].split(' ') if j != ''][1])
		end_coord_hit = int([i for i in in_water if i.startswith(water_name.split('/')[-1][:8])][-1].split(' ')[-1])
		align_len = end_coord_hit - initial_coord_hit

		prot_orig = coords[k][2]
		nuc_orig = coords[k][3]

		start_pos = check_5prime(prot_orig, initial_coord_hit)
		end_pos, terminated = check_3prime(prot_orig, end_coord_hit, args)

		if terminated == 'n':
			prot_ORF = prot_orig[start_pos:end_pos]
			nuc_ORF = nuc_orig[(start_pos)*3:(end_pos)*3]

		else:
			if end_pos - end_coord_hit > align_len*.15:
				end_pos = end_coord_hit
			else:
				pass
			prot_ORF = prot_orig[start_pos:end_pos]
			nuc_ORF = nuc_orig[(start_pos)*3:(end_pos+1)*3]

		new_len = str(len(nuc_ORF))
		new_name = '>'+k.split('\t')[0].split('Len')[0]+'Len'+new_len+'_'+'_'.join(k.split('\t')[0].split('_')[3:])

		coords[k].append(new_name+'\n'+prot_ORF)
		coords[k].append(new_name+'\n'+nuc_ORF)

	for bad_data in keys_bad:
		coords.pop(bad_data, None)

	return coords
	
###########################################################################################
###---------------- Returns the Newly Extracted ORF Data as Fasta Files ----------------###
###########################################################################################

def write_ORFs(coords, args):

	print (color.BOLD+'Collecting and Finalizing'+color.ORANGE+' ORFs\n\n'+color.END)
	
	final_ORFs = post_water_ORF_extract(coords, args)
	
	with open(args.nuc_out,'w+') as w:
		for k, v in coords.items():
			w.write(v[-1]+'\n')

	with open(args.prot_out,'w+') as x:
		for k, v in coords.items():
			x.write(v[-2]+'\n')


###########################################################################################
###------------ Evaluates the Frequency of in-Frame Stop Codons (Optional) -------------###
###########################################################################################
			
def post_water_StopEval(coords, args):
	
	inFrameStops = {'TGA':0}
	inFrameStops['TAA'] = 0
	inFrameStops['TAG'] = 0

	Seqs_inFrameStop = {}
	Seqs_inFrameStop.setdefault('TGA',[])
	Seqs_inFrameStop.setdefault('TAA',[])
	Seqs_inFrameStop.setdefault('TAG',[])

	seqs_with_inFrameStop = []

#### NOTE: the "codons[:-4]" is intentional to reduce noise from "poorly" aligned ends
#### ("translational readthrough") at a "True" termination signal

	for k, v in coords.items():
		if 'X' in v[-2].split('\n')[-1]:
			nuc_ORF = v[-1]
			seqs_with_inFrameStop.append(nuc_ORF)
			codons = SplitByCodon(nuc_ORF.split('\n')[-1])
			inSeqStop = 0
			inFrameStops['TGA'] += codons[:-4].count('TGA')
			inSeqStop += codons[:-1].count('TGA')
			if codons[:-1].count('TGA') > 0:
				Seqs_inFrameStop['TGA'].append(nuc_ORF)
			inFrameStops['TAG'] +=codons[:-4].count('TAG')
			inSeqStop += codons[:-1].count('TAG')
			if codons[:-1].count('TAG') > 0:
				Seqs_inFrameStop['TAG'].append(nuc_ORF)
			inFrameStops['TAA'] += codons[:-4].count('TAA')
			inSeqStop += codons[:-1].count('TAA')
			if codons[:-1].count('TAA') > 0:
				Seqs_inFrameStop['TAA'].append(nuc_ORF)
		
	with open(args.input_file.split('.fas')[0]+'.StopCodonPresence.tsv','w+') as w:
		total_bp = sum([len(coords[k][-1]) for k in coords.keys()])/3
		w.write('Stop Codon\tOverall in-Frame Count\tFrequency (Per Thousand Codons)\n')
		w.write('TGA\t'+str(inFrameStops['TGA'])+'\t'+"%.3f" % (inFrameStops['TGA']*1000/float(total_bp))+'\n')
		w.write('TAG\t'+str(inFrameStops['TAG'])+'\t'+"%.3f" % (inFrameStops['TAG']*1000/float(total_bp))+'\n')
		w.write('TAA\t'+str(inFrameStops['TAA'])+'\t'+"%.3f" % (inFrameStops['TAA']*1000/float(total_bp))+'\n')
	
	TGA_Print = '  TGA\t---\t'+str(inFrameStops['TGA'])+'\t---\t'+"%.3f" % (inFrameStops['TGA']*1000/float(total_bp))+'\n'
	TAA_Print = '  TAA\t---\t'+str(inFrameStops['TAA'])+'\t---\t'+"%.3f" % (inFrameStops['TAA']*1000/float(total_bp))+'\n'
	TAG_Print = '  TAG\t---\t'+str(inFrameStops['TAG'])+'\t---\t'+"%.3f" % (inFrameStops['TAG']*1000/float(total_bp))+'\n'

	print (color.BOLD+'Estimated frequency of '+color.ORANGE+'in-frame '\
	'Termination Codons'+color.END)

	print (color.BOLD+'\n'+'#'*70+'\n\n'+color.ORANGE+TGA_Print+TAA_Print+TAG_Print+color.END)
	
	print (color.BOLD+'\nThese estimates are saved as '+color.DARKCYAN+args.input_file.split('/')[-1]\
	.split('.fas')[0]+'.StopCodonPresence.tsv\n\n'+color.END)

###########################################################################################
###----------------------- Performs the General Data Prep Steps ------------------------###
###########################################################################################

def prep_data_Analyses(args):

	prep_folders(args)
	
	codon_table = no_stop_table
	
	coords = prep_sequences(args, codon_table)

	print (color.BOLD+'\n\nFound and prepared '+color.GREEN+str(len(coords))+color.END+\
	color.BOLD+' valid transcripts\n\n'+color.END)

	if args.skip_water == False:

		water_align2(coords, args)

	else:
		found_water_files = [i for i in os.listdir(args.storage) if i.endswith('water')]
		expected_water_names = [k.replace('\t','_')+'.water' for k in coords.keys()]
		temp_eval = len(list(set(expected_water_names).intersection(found_water_files)))
		if temp_eval != len(expected_water_names):
			print (color.BOLD+color.RED+'#'*70+'\n\nError: '+color.END+color.BOLD+'Missing necessary '\
			'"water" alignment files.\n\nPlease re-run this script '+color.RED+'without '+color.END+\
			'the '+color.END+color.ORANGE+color.BOLD+'"--skip_water"'+color.END+color.BOLD+\
			' flag\n\n'+color.END)
			sys.exit()
		else:
			pass		
	
	print (color.BOLD+'Processing information to collect'+color.ORANGE+' ORFs\n\n'+color.END)	
		
	updated_ORFs = post_water_ORF_extract(coords, args)
	
	return updated_ORFs


###########################################################################################
###---------------- Carries Out In-Frame Termination Codon Evaluations -----------------###
###########################################################################################

def Eval_GeneticCode(args):

	coords = prep_data_Analyses(args)
	
	post_water_StopEval(coords, args)
	

###########################################################################################
###---------------- Carries Out ALL ORF Identification/Extraction Steps ----------------###
###########################################################################################

def extract_ORFs(args):

	coords = prep_data_Analyses(args)
	
	write_ORFs(coords, args)


###########################################################################################
###------------ General Clean-Up Step (Removes Temporary water-Alignments) -------------###
###########################################################################################

def clean_up(args):

	for f in os.listdir(args.storage):
		os.system('rm '+f)

			
def main():
	
	args = check_args()

	check_paths(args)
	
	if args.evaluate == False:
		print (color.BOLD+'\n\nThis script will identify and extract '+color.ORANGE+'O'+color.END+\
		color.BOLD+'pen '+color.ORANGE+'R'+color.END+color.BOLD+'eading '+color.ORANGE+'F'\
		+color.END+color.BOLD+'rame'+color.ORANGE+'s '+color.END+color.BOLD+'from:\t'+\
		color.DARKCYAN+args.input_file.split('/')[-1]+'\n'+color.END)
		
		extract_ORFs(args)

	else:
		print (color.BOLD+'\n\nThis script will evaluate the frequency '+color.ORANGE+'in-frame '\
		'termination\ncodons'+color.END+color.BOLD+' from the '+color.ORANGE+'O'+color.END+\
		color.BOLD+'pen '+color.ORANGE+'R'+color.END+color.BOLD+'eading '+color.ORANGE+'F'+\
		color.END+color.BOLD+'rame'+color.ORANGE+'s '+color.END+color.BOLD+'to evalute the'\
		'\ngenetic code of:   '+color.DARKCYAN+args.input_file.split('/')[-1]+\
		'\n\n'+color.END+color.BOLD+'#'*70+color.END)
		
		Eval_GeneticCode(args)
		
main()
	
			
		





		