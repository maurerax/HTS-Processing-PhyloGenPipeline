#!/usr/bin/env python

##__Updated__: 20_02_2018
##__Author__: Xyrus Maurer-Alcalá; maurerax@gmail.com; xyrus.maurer-alcala@izb.unibe.ch
##__Usage__: python 3_CallORFs.py
##__Options__: python 3_CallORFs.py --help



from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Data.CodonTable import CodonTable
from Bio.Emboss.Applications import WaterCommandline
import argparse, os, re, sys, shutil, time
from argparse import RawTextHelpFormatter,SUPPRESS

###########################################################################################
#------------------------ Supported Codon Tabels (Genetic Codes) -------------------------#
###########################################################################################

blepharisma_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y',                       
	'TGT': 'C', 'TGC': 'C', 'TGA': 'W', 'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = ['TAA','TAG'])

condylostoma_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y', 'TAA': 'Q', 'TAG': 'Q',
	'TGT': 'C', 'TGC': 'C', 'TGA': 'W', 'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = [''])

c_uncinata_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y',             'TAG': 'Q',
	'TGT': 'C', 'TGC': 'C', 'TGA': 'Q', 'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = ['TAA'])

euplotes_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y',                       
	'TGT': 'C', 'TGC': 'C', 'TGA': 'C', 'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = ['TAA','TAG'])

myrionecta_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y', 'TAA': 'Y', 'TAG': 'Y',
	'TGT': 'C', 'TGC': 'C',             'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = ['TGA'])

no_stop_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y', 'TAA': 'X', 'TAG': 'X',
	'TGT': 'C', 'TGC': 'C', 'TGA': 'X', 'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = [''])

peritrich_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y', 'TAA': 'E', 'TAG': 'E',
	'TGT': 'C', 'TGC': 'C',             'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = ['TGA'])
	
tag_table = CodonTable(forward_table={
	'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
	'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
	'TAT': 'Y', 'TAC': 'Y', 'TAA': 'Q',            
	'TGT': 'C', 'TGC': 'C', 'TGA': 'Q', 'TGG': 'W',
	'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
	'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
	'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
	'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
	'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
	'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
	'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
	'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
	'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
	'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
	'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
	'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'},
	start_codons = [ 'ATG'],
	stop_codons = ['TAG'])

###########################################################################################
#------------------------------ Colors For Print Statements ------------------------------#
###########################################################################################

class color:
   PURPLE = '\033[95m'
   CYAN = '\033[96m'
   DARKCYAN = '\033[36m'
   ORANGE = '\033[38;5;214m'
   BLUE = '\033[94m'
   GREEN = '\033[92m'
   YELLOW = '\033[93m'
   RED = '\033[91m'
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'


###########################################################################################
#-----------------------------------------------------------------------------------------#
#------------------------------- Main Functions of Script --------------------------------#
#-----------------------------------------------------------------------------------------#
###########################################################################################

###########################################################################################
###--------------------- Parses and Checks Command-Line Arguments ----------------------###
###########################################################################################

def check_args():

	parser = argparse.ArgumentParser(description=
	color.BOLD+'\nThis script will extract '+color.ORANGE+'ALL NUCLEOTIDE ORFs'+color.END+color.BOLD+\
	' from a transcriptome.\n\nNote that this is done through '+color.BOLD+color.RED+\
	'pair-wise alignments'+color.END+color.BOLD+' comparing the transcript\nto the corresponding '\
	+color.BOLD+color.RED+'OG-database "hit"'+color.END+color.BOLD+'.'+color.END+usage_msg(), 
	usage=SUPPRESS,formatter_class=RawTextHelpFormatter)
	
	required_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Required Options'+color.END)

	required_arg_group.add_argument('--input_file','-in', action='store',
	help=color.BOLD+color.GREEN+" Fasta file of transcripts\n"+color.END)

	optional_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Options'+color.END)

	optional_arg_group.add_argument('--evaluate','-e', action='store_true',
	help=color.BOLD+color.GREEN+' Evaluates the presence and abundance of in-Frame\n termination codons'\
	' (i.e. Non-canonical genetic codes)\n'+color.END)

	optional_arg_group.add_argument('--genetic_code','-g', action='store', default=None,
	help=color.BOLD+color.GREEN+' Genetic code to use for translation\n'+color.END)

	optional_arg_group.add_argument('--align','-a', action='store_true',
	help=color.BOLD+color.GREEN+' Alignment-based ORF identification (default=On)\n'+color.END)

	optional_arg_group.add_argument('--blind','-b', action='store_true',
	help=color.BOLD+color.GREEN+' "Blindly" identifies ORFs (very fast, but less "precise"; default=Off)\n'+color.END)

	optional_arg_group.add_argument('--skip_water','-sw', action='store_true', default=False,
	help=color.BOLD+color.GREEN+' Skips "water" alignments if previously performed\n'+\
	' Include if the "genetic code evaluation" step was performed\n'+color.END)
	
	optional_arg_group.add_argument('--list_codes','-codes', action='store_true',
	help=color.BOLD+color.GREEN+' Lists supported genetic codes\n'+color.END)

	optional_arg_group.add_argument('--clean','-clean', action='store_true',
	help=color.BOLD+color.GREEN+' Will remove the temporary alignment files and directory\n'\
	'   (default is to keep these files, can be LARGE)'+color.END)

	optional_arg_group.add_argument('-author', action='store_true',
	help=color.BOLD+color.GREEN+' Print author contact information\n'+color.END)
	

	if len(sys.argv[1:]) == 0:
		print (parser.description)
		print ('\n')
		sys.exit()

	args = parser.parse_args()
	
	if args.input_file != None:
		args.tsv_file = '/'.join(args.input_file.split('/')[:-1])+'/SpreadSheets/'+[i for i in os.listdir('/'.join(args.input_file.split('/')[:-1])+'/SpreadSheets/') if i.endswith('all_eukresults')][0]
	
# 	quit_eval = return_more_info(args)
# 	if quit_eval > 0:
# 		sys.exit()

	if args.align == args.blind == False:
		args.align = True

	if args.genetic_code == None:
		args.genetic_code = 'universal'

	args.euk_db = '../../Databases/db_Fasta/EukDB.fasta'
	args.home_folder = '../'+args.input_file.split('/')[1]
	args.out_folder = args.home_folder+'/Translations_PreOG/'
	args.storage = args.out_folder+'/WaterAlign_Storage/'


	args.nuc_out = args.out_folder+args.input_file.split('/')[-1].split('.fas')[0]+'.'+args.genetic_code.title()+'.NTD.fasta'
	args.prot_out = args.nuc_out.replace('.NTD', '.AA')
	args.tsv_out = args.nuc_out.replace('.NTD.fasta', '.EukTransResults.tsv')

	print (args.tsv_file)

# 	print(args.nuc_out)
# 	sys.exit()
	
	return args


###########################################################################################
###------------------------------- Script Usage Message --------------------------------###
###########################################################################################

def usage_msg():

	example_no_idea_code = color.RED+'Example usage (evaluating genetic code):\n'+color.CYAN+\
	'python ExtractORFs.py --input_file ../Op_me_Xxma/Op_me_Xxma_WTA_NBU.Renamed.fasta '\
	'--evaluate'+color.END

	example_with_code = color.RED+'Example usage (with known genetic code):\n'+color.CYAN+\
	'python ExtractORFs.py --input_file ../Op_me_Xxma/Op_me_Xxma_WTA_NBU.Renamed.fasta '\
	'--genetic_code universal'+color.END

	example_quick_code = color.RED+'Example usage (with known genetic code and "quick", '\
	'see guide):\n'+color.CYAN+'python ExtractORFs.py --input_file ../Op_me_Xxma/Op_me_Xxma_WTA_NBU.'\
	'Renamed.fasta --genetic_code universal --blind'+color.END



	return (color.BOLD+color.RED+'\n\nExample usage (evaluating genetic code):\n'+color.CYAN+'python ExtractORFs.py'\
	' --input_file ../Op_me_Xxma/Op_me_Xxma_WTA_NBU.Renamed.fasta --evaluate\n\n'+color.RED+'Example usage'\
	' (with known genetic code):\n'+color.CYAN+'python ExtractORFs.py --input_file '\
	'../Op_me_Xxma/Op_me_Xxma_WTA_NBU.Renamed.fasta --genetic_code universal'+color.END)








##########################################################################################
###-------- Storage for LARGE (Annoying) Print Statements for Flagged Options ---------###
##########################################################################################

def return_more_info(args):

	valid_arg = 0

	author = (color.BOLD+color.ORANGE+'\n         Questions/Comments? Email Xyrus (author)\n'\
	+color.PURPLE+'\n   maurerax@gmail.com or xyrus.maurer-alcala@izb.unibe.ch\n\n'+color.END)

	supported_gcodes_names = ['bleph','blepharisma','chilo','chilodonella','condy',\
	'condylostoma','none','eup','euplotes','peritrich','vorticella','ciliate','universal',\
	'taa','tag','tga']

	supported_gcodes_list = ['Blepharisma\t(TGA = W)','Chilodonella\t(TAG/TGA = Q)','Ciliate\t\t(TAR = Q)',\
	'Conylostoma\t(TAR = Q, TGA = W)','Euplotes\t(TGA = C)','Peritrich\t(TAR = E)','None\t\t(TGA/TAG/TAA = X)',\
	'Universal\t(TGA/TAG/TAA = STOP)','TAA\t\t(TAG/TGA = Q)', 'TAG\t\t(TRA = Q)', 'TGA\t\t(TAR = Q)']

	if args.genetic_code != None and args.genetic_code.lower() not in supported_gcodes_names:
		print (color.BOLD+color.RED+'\nError: '+color.END+color.BOLD+'Provided genetic code is'\
		' currently unsupported.\n\nIf you have a new genetic code, please contact the author'\
		' (with some evidence).\n\nOtherwise, use one of the currently supported genetic codes.\n'\
		+color.END)
		print (color.BOLD+color.ORANGE+'\n'.join(supported_gcodes_list)+'\n\n'+color.END)
		print (author)
		valid_arg += 1

	elif args.list_codes == True:
		print (color.BOLD+color.RED+'\nThese are the currently supported genetic codes.\n'+color.END)
		print (color.BOLD+color.ORANGE+'\n'.join(supported_gcodes_list)+'\n\n'+color.END)
		valid_arg += 1	
		print (author)
		valid_arg += 1

	elif args.author == True and args.list_codes != True:
		print (author)
		valid_arg += 1

	if args.input_file != None:
		if os.path.isfile(args.input_file) != False:
			if args.input_file.split('/')[-1] not in os.listdir('/'.join(args.input_file.split('/')[:-1])):
				print (color.BOLD+color.RED+'\nError:'+color.END+color.BOLD+' The provided Fasta file '\
				'('+color.DARKCYAN+args.input_file.split('/')[-1]+color.END+color.BOLD+')\ndoes not'\
				' exist or is incorrectly formatted.\n\nDouble-check then try again!\n\n'+color.END) 
				valid_arg += 1
			elif args.input_file.endswith('WTA_NBU.Renamed.fasta') != True:
				print (color.BOLD+'\n\nInvalid Fasta File! Only Fasta Files that were processed'\
				' with '+color.GREEN+'3_CountOGsUsearch.py '+color.END+color.BOLD+'are valid\n\n'\
				'However, to bypass that issue, Fasta Files MUST end with '+color.CYAN+\
				'"WTA_NBU.Renamed.fasta"\n\n'+color.END)
				valid_arg += 1
		else:
			print (color.BOLD+color.RED+'\nError:'+color.END+color.BOLD+' The provided Fasta file '\
			'('+color.DARKCYAN+args.input_file.split('/')[-1]+color.END+color.BOLD+')\ndoes not'\
			' exist or is incorrectly formatted.\n\nDouble-check then try again!\n\n'+color.END) 
			valid_arg += 1

		if os.path.isfile(args.tsv_file) != True:
			print (color.BOLD+color.RED+'\nError:'+color.END+color.BOLD+' The TSV file '\
			'('+color.DARKCYAN+args.tsv_file.split('/')[-1]+color.END+color.BOLD+')\ndoes not'\
			' exist or is incorrectly formatted.\n\nDouble-check then try again!\n\n'+color.END) 
			valid_arg += 1
	
	return valid_arg

	
def check_input():
	pass

	
###########################################################################################
###--------------------------- Does the Inital Folder Prep -----------------------------###
###########################################################################################

def prep_folders(args):
	
	if os.path.isdir(args.out_folder) != True:
		os.system('mkdir '+args.out_folder)
	
	if args.evaluate == True or args.align == True:
		if os.path.isdir(args.storage) != True:
			os.system('mkdir '+args.storage)

	if os.path.isdir('../TranslatedTranscriptomes/') != True:
		os.system('mkdir ../TranslatedTranscriptomes/')


###########################################################################################
###---------------- Checks the location of "water" and the OG database -----------------###
###########################################################################################

def validate_executables():
	
	water = shutil.which('water')
		
	if water == None:
		print (color.BOLD+'\n'+'#'*70+color.RED+'\n\nError: "water" (from the EMBOSS package)'\
		' is not in your path.\n\n'+color.END+color.BOLD+'Please install EMBOSS and put the '\
		'packages into your path.\n'+color.END)
		sys.exit()


###########################################################################################
#-----------------------------------------------------------------------------------------#
#------------------------------- General Useful Functions --------------------------------#
#-----------------------------------------------------------------------------------------#
###########################################################################################

###########################################################################################
###---------------------- Makes Translation Steps (Later) Easier -----------------------###
###########################################################################################

def standardize_gcode(given_code, evaluate):

	if given_code == 'ciliate' or given_code == 'tga':
		codon_table = 6
		print_state =  color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END	

	elif given_code == 'chilodonella' or given_code == 'chilo' or given_code == 'taa':
		codon_table = c_uncinata_table
		print_state =  color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END	

	elif given_code == 'blepharisma' or given_code == 'bleph':
		codon_table = blepharisma_table
		print_state =  color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END	

	elif given_code == 'euplotes' or given_code == 'eup':
		codon_table = euplotes_table
		print_state =  color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END	

	elif given_code == 'myrionecta' or given_code == 'mesodinium':
		codon_table = myrionecta_table
		print_state =  color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END	

	elif given_code == 'peritrich' or given_code == 'vorticella':
		codon_table = peritrich_table
		print_state =  color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END	

	elif given_code == 'none':
		codon_table = no_stop_table
		print_state =  color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END	

	elif given_code == 'condylostoma' or given_code == 'condy':
		codon_table = condylostoma_table
		print_state =  color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END	

	elif given_code == 'tag':
		codon_table = tag_table
		print_state =  color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END	

	elif given_code == 'universal':
		codon_table = 1
		print_state =  color.BOLD+'\nTranslating transcripts with the '+color.PURPLE+\
		given_code.title()+' code'+color.END	

	else:
		print_state =  color.BOLD+color.RED+'\nNo valid genetic code provided!\n\n'+color.END+\
		color.BOLD+'Translating all stop codons as '+color.PURPLE+'"X" (by default)'\
		+color.END+color.BOLD+'\n\nPlease check that the code you wish to use is supported:'\
		+color.CYAN+'\n\npython 5_GCodeTranslate.py -list_codes'+color.END
		codon_table = no_stop_table
	
	if evaluate != True:
		print(print_state)

	return codon_table
	
		
###########################################################################################
###----------------------------- Breaks ORF Into Codons --------------------------------###
###########################################################################################

def SplitByCodon(given_seq):
	codons = [given_seq[n:n+3] for n in range(0, len(given_seq),3)]
	return codons


##########################################################################################
###------------------------ Rounds Down Values to Nearest "3" -------------------------###
##########################################################################################

def estimated_start_dist(num):
	min_val = int(num*3*.5)-int(num*3*.5)%3
	max_val = int(num*6)-int(num*6)%3
	return min_val, max_val


###########################################################################################
###----------------------- Performs the General Data Prep Steps ------------------------###
###########################################################################################

def prep_sequences(args, codon_table):
	
	intsv = [i for i in open(args.tsv_file).read().split('\n') if i != '']
	print ('\n'+color.BOLD+'#'*70+'\n'+color.END)
	print (color.BOLD+'Gathering transcripts from: '+color.DARKCYAN+args.input_file.split('/')[-1]+color.END)
	
	infasta = {i.description:str(i.seq) for i in SeqIO.parse(args.input_file,'fasta')}

	coords = {'\t'.join(i.split('\t')[:2]):[int(i.split('\t')[6]),int(i.split('\t')[7])] for i in intsv}

	if args.align == True or args.evaluate == True:
	
		og_hits = list(set([k.split('\t')[-1] for k in coords.keys()]))

		if args.skip_water == False:
			print ('\n'+color.BOLD+'#'*70+'\n'+color.END)
			print (color.BOLD+'Collecting "hits" to representative OG-database. '\
			'This can take a while.'+color.END)
			ogfasta = {i.description:str(i.seq) for i in SeqIO.parse(args.euk_db,'fasta') if i.description in og_hits}

		for k, v in coords.items():
			orig_seq = infasta[k.split('\t')[0]]
			seq_len = int(k.split('Len')[1].split('_')[0].split('\t')[0])

			if int(v[1]) > int(v[0]):
				start_pos = int(v[0])
				if start_pos%3 != 0:
					cut = (start_pos)%3-1
				else:
					cut = 2
				if (seq_len-cut)%3 != 0:
					end_pos = -((seq_len-cut)%3)
				else:
					end_pos = None

				coords[k].append(str(Seq(orig_seq)[cut:end_pos].translate(table=codon_table)).replace('*','X'))
				coords[k].append(str(orig_seq[cut:end_pos]))

				if args.skip_water == False:
					coords[k].append(ogfasta[k.split('\t')[-1]])				

			elif int(v[0]) > int(v[1]):
				start_pos = int(v[0])
				cut = (seq_len - start_pos)%3

				if (seq_len-cut)%3 != 0:
					end_pos = -((seq_len-cut)%3)
				else:
					end_pos = None

				coords[k].append(str(Seq(orig_seq).reverse_complement()[cut:end_pos].translate(table=codon_table)).replace('*','X'))
				coords[k].append(str(Seq(orig_seq).reverse_complement()[cut:end_pos]))

				if args.skip_water == False:
					coords[k].append(ogfasta[k.split('\t')[-1]])				
	else:
		for i in intsv:
			key = '\t'.join(i.split('\t')[:2])
			val = coords[key]
			if val[0] < val[1]:
				coords[key] = [val[0]-1, val[1], int(i.split('\t')[-4]), infasta[key.split('\t')[0]]]
			else:
				seq_len = int(key.split('Len')[1].split('_')[0])
				true_start = seq_len-val[0]
				true_end = seq_len-val[1]
				coords[key]=[true_start, true_end, int(i.split('\t')[-4]),str(Seq(infasta[key.split('\t')[0]]).reverse_complement())]

		for k, v in coords.items():
			if len(v) != 4:
				coords.pop(k, None)

	return coords


###########################################################################################
###----------------------- Returns Summary of the Processed Data -----------------------###
###########################################################################################

def summarize_data(coords, args):
	
	if args.blind == True and args.align == False:
		
		ORFs = "{:,}".format(len(coords))
		nuc_pos = "{:,}".format(sum([len(i[-2].split('\n')[-1]) for i in coords.values()]))
		aa_pos = "{:,}".format(sum([len(i[-1].split('\n')[-1]) for i in coords.values()]))

	elif args.blind == False and args.align == True:
		ORFs = "{:,}".format(len(coords))
		nuc_pos = "{:,}".format(sum([len(i[-1].split('\n')[-1]) for i in coords.values()]))
		aa_pos = "{:,}".format(sum([len(i[-2].split('\n')[-1]) for i in coords.values()]))

	ORF_line = color.ORANGE+'   O'+color.END+color.BOLD+'pen '+color.ORANGE+\
	'R'+color.END+color.BOLD+'eading '+color.ORANGE+'F'+color.END+color.BOLD+'rame'+\
	color.ORANGE+'s'+color.END+color.BOLD+':   \t'+color.ORANGE+ORFs+color.END+'\n'+color.BOLD
	
	Nuc_line = color.GREEN+'   N'+color.END+color.BOLD+'ucleo'+color.GREEN+'T'+color.END+\
	color.BOLD+'i'+color.GREEN+'D'+color.END+color.BOLD+'e Positions:    \t'+color.GREEN+\
	nuc_pos+color.END+'\n'+color.BOLD
	
	AA_line = color.CYAN+'   A'+color.END+color.BOLD+'mino '+color.CYAN+'A'+color.END+\
	color.BOLD+'cid Residues:   \t'+color.CYAN+aa_pos+color.END

	print (color.BOLD+'#'*70+'\n'+color.END)
	print (color.BOLD+'Data summary for '+color.DARKCYAN+args.input_file.split('/')[-1]+\
	color.END+color.BOLD+':\n'+ORF_line+Nuc_line+AA_line+'\n'+color.END)
	
	
#-----------------------------------------------------------------------------------------#
#---------------------- BLIND ORF Identification/Extraction Steps ------------------------#
#-----------------------------------------------------------------------------------------#
	
###########################################################################################
###----------- "Blindly" Scans 5-Prime End of Transcript for In-Frame "ATG" ------------###
###########################################################################################

def blind_5prime_check(check_seq, max_start, min_start, orig_start, codon_table):
	## Looks for in-frame STOP codons in the UTR of the transcript
	prime5 = str(Seq(check_seq[max_start:min_start]).translate(table=codon_table)).replace('*','x')
	in_frame_stops = [stops.start() for stops in re.finditer('x',prime5)]
	## Looks for in-frame START codons in the UTR of the transcript
	in_frame_starts = [starts.start() for starts in re.finditer('M',prime5)]
	## Checks that there are NO in-frame STOP codons between the possible "new" START codon 
	## and the aligned portion of the transcript -- THIS is double checked!
	if len(in_frame_starts) != 0:
		if len(in_frame_stops) != 0:
			if in_frame_stops[-1] < in_frame_starts[-1]:
				new_start = max_start+in_frame_starts[-1]*3
			else:
				new_start = orig_start
		else:
			new_start = max_start+in_frame_starts[-1]*3
	else:
		new_start = orig_start
	## Skips the double-checking if there are no GOOD potential START codons
	if new_start == orig_start:
		updated_start = orig_start		
	else:
		eval_updated = str(Seq(check_seq[new_start:orig_start]).translate(table=1)).replace('*','x')		
		eval_updated_stops = [stops.start() for stops in re.finditer('x',eval_updated)]
		eval_updated_starts = [starts.start() for starts in re.finditer('M',eval_updated)]
		if len(eval_updated_stops) != 0:
			if len(eval_updated_starts) != 0:
				good_starts = [i for i in eval_updated_starts if i > eval_updated_stops[-1]]
				good_starts.sort()
				if len(good_starts) != 0:
					updated_start = new_start+good_starts[0]*3
				else:
					updated_start = orig_start
			else:
				updated_start = orig_start
		else:
			updated_start = new_start
	return updated_start
			

###########################################################################################
###---------- "Blindly" Extracts the ORF from the Fasta File and SpreadSheet -----------###
###########################################################################################

def blind_ORF_extract(args, codon_table):

	coords = prep_sequences(args, codon_table)	

	print ('\n'+color.BOLD+'#'*70+'\n'+color.END)
	print (color.BOLD+'Found and prepared '+color.GREEN+"{:,}".format(len(coords))+color.END+\
	color.BOLD+' valid transcripts.'+color.END)

	print ('\n'+color.BOLD+'#'*70+'\n'+color.END)
	print (color.BOLD+'Processing information to collect'+color.ORANGE+' ORFs.'+color.END)	
	
	for k, v in coords.items(): #coords.items():
		ref_start = v[2]
		orig_start = v[0]
		if orig_start == 1:
			orig_start = 0
		if ref_start != 1:
			min_dist, max_dist = estimated_start_dist(ref_start)
			min_start = orig_start-min_dist
			max_start = orig_start-max_dist
			if min_start < 0:
				min_start = orig_start
			if max_start < 0:
				max_start = min_start%3
			updated_start = blind_5prime_check(v[-1], max_start, min_start, orig_start, codon_table)		
		else:
			updated_start = orig_start
		temp_seq = coords[k][-1][updated_start:]
		## Uses the given genetic code to identify the stop position of the ORF
		temp_prot = str(Seq(temp_seq).translate(table=codon_table))							
		if '*' in temp_prot:		
			stop_pos = (temp_prot.index('*')+1)*3
			coords[k].append(temp_seq[:stop_pos])
			coords[k].append(str(Seq(v[-1]).translate(table=codon_table)).rstrip('*'))
		else:
			stop_pos = (coords[k][1] - coords[k][0]) - (coords[k][1] - coords[k][0])%3
			coords[k].append(temp_seq[:stop_pos])
			coords[k].append(str(Seq(v[-1]).translate(table=codon_table)).rstrip('*'))

	awkward_list = []

	for k, v in coords.items():
		expected_min = (v[0] - v[1])-1
		if len(v[-2]) < expected_min:
			awkward_list.append(k)

	if len(awkward_list) != 0:
		with open('AtypicallyShortProts.txt','w+') as x:
			for entry in awkward_list:
				x.write(entry+'\n')
	
	return coords
	

#-----------------------------------------------------------------------------------------#
#------------------ WATER-Alignment ORF Identification/Extraction Steps ------------------#
#-----------------------------------------------------------------------------------------#

###########################################################################################
###-------------- Checks for Alternative Upstream "Start" Codon Positions --------------###
###########################################################################################

def check_5prime(prot_seq, initial_coord_hit):

	methionine_start = [pos for pos in [s for s, i in enumerate(prot_seq) if i == 'M'] if pos < initial_coord_hit]
	stop_codons_early = [pos for pos in [s for s, i in enumerate(prot_seq) if i == 'X'] if pos < initial_coord_hit]

	if len(methionine_start) == 0:
		methionine_start = initial_coord_hit-1
	else:
		methionine_start = methionine_start[-1]	

	if len(stop_codons_early) == 0:
		pass
	else:
		stop_codons_early = stop_codons_early[-1]	
		if stop_codons_early > methionine_start:
			methionine_start = initial_coord_hit-1

	return methionine_start


###########################################################################################
###------------ Checks for Downstream "Stop" Codons with Given Genetic Code ------------###
###########################################################################################

def check_3prime(prot_seq, end_coord_hit, args):
	if args.evaluate == False:
		stop_codons_late = [pos for pos in [s for s, i in enumerate(prot_seq) if i == 'X'] if pos >= end_coord_hit]
		if len(stop_codons_late) != 0:
			stop_codons_late = stop_codons_late[0]
			terminate = 'y'
		else:
			stop_codons_late = end_coord_hit
			terminate = 'n'
	else:
		stop_codons_late = end_coord_hit
		terminate = 'n'

	return stop_codons_late, terminate


###########################################################################################
###------------ Evaluates the Frequency of in-Frame Stop Codons (Optional) -------------###
###########################################################################################
			
def post_water_StopEval(coords, args):
	
	inFrameStops = {'TGA':0}
	inFrameStops['TAA'] = 0
	inFrameStops['TAG'] = 0

	Seqs_inFrameStop = {}
	Seqs_inFrameStop.setdefault('TGA',[])
	Seqs_inFrameStop.setdefault('TAA',[])
	Seqs_inFrameStop.setdefault('TAG',[])

	seqs_with_inFrameStop = []

#### NOTE: the "codons[:-4]" is intentional to reduce noise from "poorly" aligned ends
#### ("translational readthrough") at a "True" termination signal

	for k, v in coords.items():
		if 'X' in v[-2].split('\n')[-1]:
			nuc_ORF = v[-1]
			seqs_with_inFrameStop.append(nuc_ORF)
			codons = SplitByCodon(nuc_ORF.split('\n')[-1])
			inSeqStop = 0
			inFrameStops['TGA'] += codons[:-4].count('TGA')
			inSeqStop += codons[:-1].count('TGA')
			if codons[:-1].count('TGA') > 0:
				Seqs_inFrameStop['TGA'].append(nuc_ORF)
			inFrameStops['TAG'] +=codons[:-4].count('TAG')
			inSeqStop += codons[:-1].count('TAG')
			if codons[:-1].count('TAG') > 0:
				Seqs_inFrameStop['TAG'].append(nuc_ORF)
			inFrameStops['TAA'] += codons[:-4].count('TAA')
			inSeqStop += codons[:-1].count('TAA')
			if codons[:-1].count('TAA') > 0:
				Seqs_inFrameStop['TAA'].append(nuc_ORF)
		
	with open(args.nuc_out.split('.fas')[0]+'.StopCodonPresence.tsv','w+') as w:
		total_bp = sum([len(coords[k][-1]) for k in coords.keys()])/3
		w.write('Stop Codon\tOverall in-Frame Count\tFrequency (Per Thousand Codons)\n')
		w.write('TGA\t'+str(inFrameStops['TGA'])+'\t'+"%.3f" % (inFrameStops['TGA']*1000/float(total_bp))+'\n')
		w.write('TAG\t'+str(inFrameStops['TAG'])+'\t'+"%.3f" % (inFrameStops['TAG']*1000/float(total_bp))+'\n')
		w.write('TAA\t'+str(inFrameStops['TAA'])+'\t'+"%.3f" % (inFrameStops['TAA']*1000/float(total_bp))+'\n')
	
	TGA_Print = '  TGA\t---\t'+str(inFrameStops['TGA'])+'\t---\t'+"%.3f" % (inFrameStops['TGA']*1000/float(total_bp))+'\n'
	TAA_Print = '  TAA\t---\t'+str(inFrameStops['TAA'])+'\t---\t'+"%.3f" % (inFrameStops['TAA']*1000/float(total_bp))+'\n'
	TAG_Print = '  TAG\t---\t'+str(inFrameStops['TAG'])+'\t---\t'+"%.3f" % (inFrameStops['TAG']*1000/float(total_bp))+'\n'

	print (color.BOLD+'Estimated frequency of '+color.ORANGE+'in-frame '\
	'Termination Codons'+color.END)

	print (color.BOLD+'\n'+'#'*70+'\n\n'+color.ORANGE+TGA_Print+TAA_Print+TAG_Print+color.END)
	
	print (color.BOLD+'These estimates are saved as '+color.DARKCYAN+args.input_file.split('/')[-1]\
	.split('.fas')[0]+'.StopCodonPresence.tsv\n'+color.END)


###########################################################################################
###------------------ Finalizes All Water-Alignment-Related Outputs --------------------###
###########################################################################################

def finalize_water_outputs(args, codon_table):

	prep_folders(args)
	
	if args.evaluate == True:
		codon_table = no_stop_table
	
	coords = prep_sequences(args, codon_table)

	print ('\n'+color.BOLD+'#'*70+'\n'+color.END)
	print (color.BOLD+'Found and prepared '+color.GREEN+"{:,}".format(len(coords))+color.END+\
	color.BOLD+' valid transcripts.'+color.END)

	if args.skip_water == False:

		water_align(coords, args)

	else:
	
		found_water_files = [i for i in os.listdir(args.storage) if i.endswith('water')]
	
		expected_water_names = [k.replace('\t','_').replace('|','.')+'.water' for k in coords.keys()]
	
		temp_eval = len(list(set(expected_water_names).intersection(found_water_files)))
	
		if temp_eval != len(expected_water_names):
			print (color.BOLD+color.RED+'#'*70+'\n\nError'+color.END+color.BOLD+': Missing necessary '\
			'"water" alignment files.\n\nPlease re-run this script '+color.RED+'without '+color.END+\
			'the '+color.END+color.ORANGE+color.BOLD+'"--skip_water"'+color.END+color.BOLD+\
			' flag\n\n'+color.END)
			sys.exit()
		else:
			pass		
	
	print (color.BOLD+'Processing information to collect'+color.ORANGE+' ORFs.\n'+color.END)	
		
	final_water_ORFs = water_ORF_extract(coords, args)
	
	return final_water_ORFs


###########################################################################################
###---------------------- Performs the "water" alignment (Emboss) ----------------------###
###########################################################################################

def water_align(coords, args):
	total_comparisons = len(coords)
	count = 0
	errors = []
	for k, v in coords.items():

		with open(args.storage+'/seq1','w+') as w:
			w.write('>'+k.split('\t')[0]+'\n'+v[2])

		with open(args.storage+'/seq2','w+') as x:
			x.write('>'+k.split('\t')[1]+'\n'+v[-1])	

		water_cline = WaterCommandline("water",asequence=args.storage+'/seq1',bsequence=args.storage+'/seq2'\
		,gapopen=10, gapextend=0.5, outfile=args.storage+'/'+k.replace('\t','_').replace('|','.')+'.water')
		
		try:
			stdout, stderr = water_cline()
		except:
			errors.append(k)
				
		count += 1

		print (color.BOLD+'Pairs Aligned: '+color.DARKCYAN+"{:,}".format(count)+'/'+"{:,}".format(total_comparisons)+\
		color.END, end = '\t\t\r')			
	
	print (color.BOLD+'Pairs Aligned: '+color.DARKCYAN+"{:,}".format(count)+'/'+"{:,}".format(total_comparisons)+\
		'\n'+color.END)
	print (color.BOLD+'#'*70+'\n'+color.END)


###########################################################################################
###------------------ Extracts ORFs from Alignment Based Measurements ------------------###
###########################################################################################

def water_ORF_extract(coords, args):

	time.sleep(1)
	
	keys_bad = []

	for k, v in coords.items():
		water_name = args.storage+'/'+k.replace('\t','_').replace('|','.')+'.water'		

		if os.path.isfile(water_name) != True:
			keys_bad.append(k)
			continue

		in_water = [i for i in open(water_name).read().split('\n') if i != '']
		initial_coord_hit = int([j for j in [i for i in in_water if i.startswith(water_name.split('/')[-1][:8])][0].split(' ') if j != ''][1])
		end_coord_hit = int([i for i in in_water if i.startswith(water_name.split('/')[-1][:8])][-1].split(' ')[-1])
		align_len = end_coord_hit - initial_coord_hit

		prot_orig = coords[k][2]
		nuc_orig = coords[k][3]

		start_pos = check_5prime(prot_orig, initial_coord_hit)
		end_pos, terminated = check_3prime(prot_orig, end_coord_hit, args)

		if terminated == 'n':
			prot_ORF = prot_orig[start_pos:end_pos]
			nuc_ORF = nuc_orig[(start_pos)*3:(end_pos)*3]

		else:
			if end_pos - end_coord_hit > align_len*.15:
				end_pos = end_coord_hit
			else:
				pass
			prot_ORF = prot_orig[start_pos:end_pos]
			nuc_ORF = nuc_orig[(start_pos)*3:(end_pos+1)*3]

		new_len = str(len(nuc_ORF))
		new_name = '>'+k.split('\t')[0].split('Len')[0]+'Len'+new_len+'_'+'_'.join(k.split('\t')[0].split('_')[3:])

		coords[k].append(new_name+'\n'+prot_ORF)
		coords[k].append(new_name+'\n'+nuc_ORF)

	for bad_data in keys_bad:
		coords.pop(bad_data, None)

	return coords
	

##########################################################################################
###----------------------- Write File with Provided Genetic Code ----------------------###
##########################################################################################

def write_data_out(coords, args):		
	
	updated_spreadsheet = {}

	if args.align == True:
		with open(args.nuc_out,'w+') as w:
			for k, v in coords.items():
				w.write(v[-1]+'\n')
				updated_spreadsheet[k.split('\t')[0]] = v[-1].split('\n')[0].strip('>')

		with open(args.prot_out,'w+') as x:
			for k, v in coords.items():
				x.write(v[-2]+'\n')


	elif args.blind == True:
		with open(args.nuc_out,'w+') as w:
			for k, v in coords.items():
				orig_name = k.split('\t')[0]

				new_name = '>'+orig_name.split('_Len')[0]+'_Len'+str(len(v[-2]))+'_'+'_'.\
				join(orig_name.split('_Len')[-1].split('_')[1:])+'\n'
			
				w.write(new_name+v[-2]+'\n')
				updated_spreadsheet[k.split('\t')[0]] = new_name.strip('>')


		with open(args.prot_out,'w+') as x:
			for k, v in coords.items():
				orig_name = k.split('\t')[0]

				new_name = '>'+orig_name.split('_Len')[0]+'_Len'+str(len(v[-2]))+'_'+'_'.\
				join(orig_name.split('_Len')[-1].split('_')[1:])+'\n'
			
				x.write(new_name+v[-1]+'\n')

	with open(args.tsv_out,'w+') as w:
		intsv = [updated_spreadsheet[i.split('\t')[0]]+'\t'+'\t'.join(i.split('\t')[1:]) \
		for i in open(args.tsv_file).read().split('\n') if i != '' and i.split('\t')[0] in\
		updated_spreadsheet.keys()]
		for i in intsv:
			w.write(i+'\n')


def final_eukdb(fasta_file, tsv_file):
	seen = []
	keep = []
	
	names = [i.strip('>') for i in open(fasta_file).read().split('\n') if i.startswith('>')] 
	
	intsv = [i for i in open(tsv_file).read().split('\n') if i != '' and i.split('\t')[0] in names]
	intsv.sort(key=lambda x: -float(x.split('\t')[-1]))
	for i in intsv:
		if i.split('\t')[0] not in seen:
			seen.append(i.split('\t')[0])
			keep.append(i)
	
	with open(tsv_file, 'w+') as w:
		for i in keep:
			w.write(i+'\n')

###########################################################################################
#-----------------------------------------------------------------------------------------#
#---------------------- Three Major Methods Controlling Data Output ----------------------#
#-----------------------------------------------------------------------------------------#
###########################################################################################

###########################################################################################
###---------------- Carries Out In-Frame Termination Codon Evaluations -----------------###
###########################################################################################

def Eval_GeneticCode(args):

	codon_table = standardize_gcode(args.genetic_code, args.evaluate)
	
	coords = finalize_water_outputs(args, codon_table)
		
	post_water_StopEval(coords, args)
	

###########################################################################################
###-------- Carries Out ALL Alignment-Based ORF Identification/Extraction Steps --------###
###########################################################################################

def extract_ORFs_align(args):

	final_eukdb(args.input_file, args.tsv_file)

	codon_table = standardize_gcode(args.genetic_code, args.evaluate)
	
	coords = finalize_water_outputs(args, codon_table)
	
	write_data_out(coords, args)
	
	summarize_data(coords, args)
	
	time.sleep(0.25)
	
	clean_up(args)


###########################################################################################
###------------ Carries Out ALL "Blind" ORF Identification/Extraction Steps ------------###
###########################################################################################

def extract_ORFs_blind(args):
	
	codon_table = standardize_gcode(args.genetic_code, args.evaluate)
	
	coords = blind_ORF_extract(args, codon_table)
	
	write_data_out(coords, args)
	
	summarize_data(coords, args)
	
	time.sleep(0.25)
	
# 	clean_up(args)


###########################################################################################
###------------ General Clean-Up Step (Removes Temporary Water-Alignments) -------------###
###########################################################################################

def clean_up(args):

	if args.align == True and args.clean == True:
		for f in os.listdir(args.storage):
			os.system('rm '+args.storage+'/'+f)
		os.system('rm -rf '+args.storage)
	elif args.align == False and args.clean == True:
		if int(sys.version[0]) > 2:
			x = input('Are you '+color.RED+'absolutely sure'+color.END+' that it is okay to remove'\
			' the water-alignments (y or n; best to say "n" if you are going to extract ORFs):  [y]')
		else:
			x = raw_input('Are you '+color.RED+'absolutely sure'+color.END+' that it is okay to remove'\
			' the water-alignments (y or n; best to say "n" if you are going to extract ORFs):  [y]')
		if 'y' in x.lower() or x != '':
			for f in os.listdir(args.storage):
				os.system('rm '+args.storage+'/'+f)
			os.system('rm -rf '+args.storage)
		else:
			pass
	
# 	os.system('cp '+args.nuc_out+' ../FinalizeTranscripts/')
# 	os.system('cp '+args.tsv_out+' ../FinalizeTranscripts/')
# 	os.system('cp '+args.prot_out+' ../FinalizeTranscripts/')
# 
# 	os.system('tar -zcf '+args.home_folder.rstrip('/')+'.tar.gz '+args.home_folder)

	
# 	os.system('mv '+args.home_folder+' ../TranslatedTranscriptomes/')



	
###########################################################################################
###-------------------------------- Next Script Message --------------------------------###
###########################################################################################

def next_script(args):
	
	nuc_out = args.nuc_out.split('/')[-1]
	prot_out = args.prot_out.split('/')[-1]
	tsv_out = args.tsv_out.split('/')[-1]
	
	
	if args.evaluate != True:

		print(color.BOLD+'Look for the following three files in the '+color.ORANGE+args.home_folder\
		.split('/')[-1]+color.END+color.BOLD+' folder:\n    '+color.GREEN+nuc_out+'\n    '+\
		color.CYAN+prot_out+'\n    '+color.PURPLE+tsv_out+color.END+'\n')
	
		print (color.BOLD+'\nNext Script is: '+color.GREEN+'4_RemovePartials.py'+color.END+\
		color.BOLD+' in the '+color.ORANGE+'FinalizeTranscripts'+color.END+color.BOLD+' folder.'\
		+color.END+'\n')

	else:

		print (color.BOLD+'\nRe-run this script: '+color.GREEN+'3t_CallORFs.py'+color.END+\
		color.BOLD+', this time using either the "slow" or "fast" ORF calling options with '\
		'an appropriate genetic code.'+color.END+'\n')

					
###########################################################################################
#-----------------------------------------------------------------------------------------#
#-------------------------- Controls All Major Steps of Script! --------------------------#
#-----------------------------------------------------------------------------------------#
###########################################################################################
		
def main():
	
	start = time.time()
	
	validate_executables()
	
	args = check_args()

	if args.evaluate == False and args.align == True and args.blind == False:
		print (color.BOLD+'\nThis script will identify and extract '+color.ORANGE+'O'+color.END+\
		color.BOLD+'pen '+color.ORANGE+'R'+color.END+color.BOLD+'eading '+color.ORANGE+'F'\
		+color.END+color.BOLD+'rame'+color.ORANGE+'s'+color.END+color.BOLD+'\nfrom: '+\
		color.DARKCYAN+args.input_file.split('/')[-1]+'\n\n'+color.END+color.BOLD+'#'*70+color.END)
		
		extract_ORFs_align(args)

	elif args.evaluate == False and args.blind == True:
		print (color.BOLD+'\nThis script will '+color.DARKCYAN+'"blindly"'+color.END+color.BOLD+\
		' identify and extract '+color.ORANGE+'O'+color.END+color.BOLD+'pen '+color.ORANGE+'R'+\
		color.END+color.BOLD+'eading '+color.ORANGE+'F'+color.END+color.BOLD+'rame'+color.ORANGE+\
		's'+color.END+color.BOLD+'\nfrom:\t'+color.DARKCYAN+args.input_file.split('/')[-1]+'\n'+color.END)

		extract_ORFs_blind(args)
	
	else:
		print (color.BOLD+'\nThis script will evaluate the frequency '+color.ORANGE+'in-frame '\
		'termination\ncodons'+color.END+color.BOLD+' from the '+color.ORANGE+'O'+color.END+\
		color.BOLD+'pen '+color.ORANGE+'R'+color.END+color.BOLD+'eading '+color.ORANGE+'F'+\
		color.END+color.BOLD+'rame'+color.ORANGE+'s '+color.END+color.BOLD+'to evalute the'\
		'\ngenetic code of: '+color.DARKCYAN+args.input_file.split('/')[-1]+\
		'\n\n'+color.END+color.BOLD+'#'*70+color.END)
		
		Eval_GeneticCode(args)
		
	end = time.time()
		
	if args.align == True or args.blind == True:
		
		print(color.BOLD+'#'*70+'\n'+color.END)
	
		next_script(args)

	hours, rem = divmod(end-start, 3600)
	minutes, seconds = divmod(rem, 60)
	print(color.BOLD+'Total Running Time:   \t'+"{:0>2}:{:0>2}:{:05.2f}".format(int(hours),int(minutes),seconds)+'\n'+color.END)
	
main()
	
			
		





		